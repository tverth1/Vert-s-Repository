"""
Timothy Verthein, S#001251514
C950 - Data Structures and Algorithms II Objective Assessment
WGUPS Routing Program

Time-complexity for this program's approach to solving the problem is 
O(n^2 log(n)). 

FILES:

wgups.py - Classes and objects
main.py  - Main program
distances.csv - formatted distance table
packages.csv  - formatted package table

This file is a script using the WGUPS.py module. It reads the files, sorts the packages, 
loads the trucks, and delivers console prompts along the way.

All custom classes are contained in the wgups.py file, as well as an overview of the
classes created for this program and the annotations.
"""


hub_name = 'Western Governors University'

# Console intro
print("# # # # # # # # # # # # # # # # # # # # # # # # # #")
print(" Welcome to WGUPS Route Planner.")
print()
print(" REQUIRED FILES:")
print(" packages.csv - Table containing package data to work with.")
print(" distances.csv - Table containing location information and distances.")
print()
print(" Ensure all files are in the same directory prior to running.")
print(" This program is configured to run with 2 available trucks.")
print(" The name of the hub is set to: " + hub_name)
print("# # # # # # # # # # # # # # # # # # # # # # # # # #")
print()

from wgups import *
import datetime, os, csv

# Finds and opens files, closes if they are not present.
try:
    LocationFile = open('distances.csv', 'r', encoding='utf-8-sig')
    PackageFile = open('packages.csv', 'r', encoding='utf-8-sig')
    print("Files found")
    print()
except:
    print("Files not found. Please put the formatted .csv files in the same directory as the script.")
    print("The package list should be named 'packages.csv', and the distance table should be named 'distances.csv'.")
    exit(0)


# dtable = distance table contains a list of rows from distances.csv
dtable = []

# locations = list of Location objects
locations = []



locations_by_address = {}

# list of package objects about to be created
packages = []
# Dictionary of packages, using their unique ID as keys.
packages_by_id = {}

locationReader = csv.reader(LocationFile)
packageReader = csv.reader(PackageFile)


# The following loops sort the data in the csv files and put them into objects in the program.
# They go through each piece of data once so they operate at O(n) time.

# Finds each row in the location table 
for row in locationReader: 
    for item in row: 
        item = item.strip() 
    dtable.append(row) 
 
# Creates new Location object with data and adds it to the list and dictionary O(n)
for row in dtable: 
    name = row[0] 
    address = row[1] 
    zipcode = row[2] 
    newloc = Location(name, address, zipcode) 
    locations.append(newloc) 
    locations_by_address[address] = newloc 
 
# Parses data in each column and creates Package object O(n)
for row in packageReader: 
    ID = row[0] 
    address = row[1] 
    city = row[2] 
    state = row[3] 
    zipcode = row[4] 
 
    deadline = row[5] 
    mass = row[6] 
    note = row[7] 
    p = Package(ID, address, zipcode, deadline, city, state, mass, note) 
    p.setDestination(locations_by_address[address]) 
    packages.append(p) 
 
# Connects locations with vertices and the distances in the table. 
# Because of the context of the problem, every location in the city has a 
# connection to every other location, making this a complete graph. The number of 
# connections in a complete graph is (n(n-1))/2, where n is the number of nodes. 
# Therefore the space-time complexity of this operation is O((n(n-1))/2). 
for loc1 in locations: 
    index1 = locations.index(loc1) 
    for loc2 in locations: 
        index2 = locations.index(loc2) 
        if(index2 == index1): 
            loc1.addConnection(loc2, 0.0) 
        elif(index1 > index2): 
            drow = dtable[index1] 
            loc1.addConnection(loc2, drow[index2 + 3]) 
        elif(index1 < index2): 
            drow = dtable[index2] 
            loc1.addConnection(loc2, drow[index1 + 3]) 
 
# Identifying the location that is the hub (start and end points on each route) O(n) 
 
for loc in locations: 
    if(loc.name == hub_name): 
        hub = loc 
        break 
 
""" 
Now that all of the data has been read, and a complete graph of the city exists, 
no additional operations will have a large impact on this program's space complexity. 
 
O((n(n-1))/2) 
 
The difficult part of the program is optimizing time-complexity since the only real 
way to find the most optimal route is to check every possible route, giving a time-complexity 
of  O(n!).
""" 
 
 
# Setting start time of 8am 
dt = datetime.datetime.strptime("8:00", "%H:%M") 
start_time = dt.time() 
 
# Two trucks in the fleet start at the start time 
truck1 = Truck(hub, start_time) 
truck2 = Truck(hub, start_time) 
 
# We will be modifying packages, so we will create a copy to hold the original master list. 
package_master_list = packages.copy() 
 
# O(n) 
# Adds packages to a dictionary with their unique ID as key, and adds a reference to the Location 
# object that represents the location the package is meant to be delivered to. 
for p in packages: 
    address = p.address 
    id = int(p.id) 
    packages_by_id[id] = p 
    loc = locations_by_address[address] 
    # p.destination is a variable that points to the Location object representing its destination. 
    p.setDestination(loc) 
 
deliverable_packages = [] 
delayed_packages = [] 
 
# package_groups is meant to mark packages that are required to be delivered from the same truck. 
package_groups = [] 
 
# delayed_packages is a list of all of the packages that are delayed and cannot go out on the first fleet. 
delayed_packages = [] 
 
# The delayed_addresses correspond to the delayed_packages and is used to find non-deadline packages headed 
# to the same location, so these locations aren't visited more times than necessary. 
delayed_addresses = [] 
 
# latest_delay determines the schedule of the extra route. It will either be after the last delayed package  
# arrives, or when the first truck is available. O(n)
latest_delay = start_time 
for p in packages: 
    if p.deadline == "EOD": 
        if (p.address in delayed_addresses) and (p not in delayed_packages): 
            delayed_packages.append(p) 
    if p.status == "Delayed": 
        delayed_packages.append(p) 
        if p.address not in delayed_addresses: 
            delayed_addresses.append(p.address) 
         
        # The latest delayed package will determine when the third route starts, 
        # provided that neither of the first two take that long... 
        if p.delay > latest_delay: 
            latest_delay = p.delay 
 
print("Packages sorted, preparing to calculate delivery plan...") 
 
 
# recycled packages keeps track of packages that were swapped for a better route. 
recycled_packages = [] 
 
def isFull(truck): 
    full = len(truck.packages) >= Truck.max_packages 
    return full 
 
""" 
The following method attempts to load the packages on the trucks in accordance to the constraints 
of the packages and the impact adding the package will have to the existing route. 
 
This results in a lot of booleaen logic with variables set up in the Package object 
that were set up upon reading the file. This method determines which of the two trucks 
is a) already visiting that address, or b) whose route is least impacted by adding the package. 
 
This method also swaps packages if there is an improvement to be made or a high-priorty constraint 
that needs to be followed on a truck. If the truck is already full, it checks to see if swapping this package 
with the package that has the worst impact will improve the route. It will always swap if there 
is a high priority constraint to be followed, i.e. a package needs to be on a specific truck. T.  
 
This process is a crucial extenstion to the core algorithm, as it provides a much larger degree of  
consistency by naturally avoiding arrangements that would cause the Nearest Neighbor algorithm 
to produce extremely inefficient results. It also has significantly improved the distance of the 
route this program produces.  
 
Maps are generated, evaluated, and if they pass all of the tests they replace the existing data. 
Since there is not a large amount of new information being kept permanent, these computations 
don't impact the space complexity of the program in a way that would change its description in O-notation. 
The space-complexity of the program relies on the complete graph constituting the map of the city, 
which is described as O((n(n-1))/2), where n is the number of locations in the program. 
 
However, this process does impact the overall time-complexity of the program, since it calls 
the core algorithm a number of times roughly equal to the product of the number of trucks and 
the number of packages. 
 
If we let n be the product of the number of trucks and the number of packages, we can see that 
the core algorithm is called O(n) times, and the core algorithm operates at a time-complexity of  
O(n log(n)).  
 
O(n) * O(n log(n)) = O(n^2 log(n)) 
 
Therefore, a more accurate time-complexity for this program's approach to solving the problem is 
O(n^2 log(n)). 
""" 
# Boolean logic - little new information as with most of these operations after the core algorithm initializes and package lists are created. 
# The operation needs to sort through the list of information about packages one time O(n)
def getBestQueue(package): 
    global truck1, truck2, hub, recycled_packages, start_time, packages_by_id 
 
    address = package.address 
 
    if package.truck1_also:
        if not isFull(truck1):
            truck1.loadPackage(package) 
            return
        else:
            recycled_packages.append(truck1.swapWithWorstPackage(package))
            return
    if package.truck1_only: 
        if not isFull(truck1): 
            truck1.loadPackage(package) 
            return
        else: 
            recycled_packages.append(truck1.swapWithWorstPackage(package)) 
            return 
 
    if package.truck2_only: 
        if not isFull(truck2): 
            truck2.loadPackage(package) 
            return 
        else: 
            recycled_packages.append(truck2.swapWithWorstPackage(package)) 
            return 

    if package.truck2_also:
        if not isFull(truck2):
            truck2.loadPackage(package) 
            return 
        else:
            recycled_packages.append(truck2.swapWithWorstPackage(package))
            return

    if len(package.deliver_with_id) > 0: 
        group = [] 
        for i in package.deliver_with_id: 
            group.append(packages_by_id[i]) 
 
        for p in group: 
            if p in truck1.packages: 
                if not isFull(truck1):
                    truck1.loadPackage(package) 
                    return 
                else: 
                    recycled_packages.append(truck1.swapWithWorstPackage(package)) 
                    return 
    
             
            elif p in truck2.packages: 
                if not isFull(truck2): 
                    truck2.loadPackage(package) 
                    return 
                else: 
                    recycled_packages.append(truck2.swapWithWorstPackage(package)) 
                    return 
    # If neither truck is full, then we decide which truck to put this package on 
    # by comparing the impact on the route. 
    if not isFull(truck1) and not isFull(truck2): 
        if address in truck1.address_list: 
            truck1.loadPackage(package) 
            return 
        elif address in truck2.address_list: 
            truck2.loadPackage(package) 
            return 


        test_map1 = truck1.getTestMap(package) 
        test_map2 = truck2.getTestMap(package) 
 
        map1 = truck1.getMap() 
        map2 = truck2.getMap() 
 
        # The impact on the route is the change in total distance. 
        delta1 = test_map1.distance - map1.distance 
        delta2 = test_map2.distance - map2.distance 
 
        if delta1 < delta2: 
            truck1.loadPackage(package) 
        else: 
            truck2.loadPackage(package) 
             
        return 

   
         
    # If a truck is already headed to the address on this package, it should always try 
    # to load them. 
    if address in truck1.address_list: 
        if not isFull(truck1): 
            truck1.loadPackage(package) 
            return
        else: 
            recycled_packages.append(truck1.swapWithWorstPackage(package)) 
            return 
 
    if address in truck2.address_list: 
        if not isFull(truck2): 
            truck2.loadPackage(package) 
            return            
        else: 
            recycled_packages.append(truck2.swapWithWorstPackage(package)) 
            return
            
 
    # Checks to see if this package will improve the route, and if it does, it swaps the package. 
    if isFull(truck1): 
        if truck1.swapImprovesRoute(package): 
            recycled_packages.append(truck1.swapWithWorstPackage(package)) 
            return 
        elif not isFull(truck2): 
            truck2.loadPackage(package) 
            return 
    else: 
        truck1.loadPackage(package) 
        return 
 
    if isFull(truck2): 
        if truck2.swapImprovesRoute(package): 
            recycled_packages.append(truck2.swapWithWorstPackage(package)) 
            return 
        elif not isFull(truck1): 
            truck1.loadPackage(package) 
 
            return 
    else: 
        truck2.loadPackage(package) 
        return 

    
 
delayed_packages = [] 


# Loads the trucks with the list of packages passed in. 
# This  
def loadTrucks(packages): 
    global hub, recycled_packages, delayed_packages, truck1, truck2, latest_delay 
 
    delayed_packages = [] 
    recycled_packages = [] 
    
 
    truck1 = Truck(hub, start_time) 
    truck2 = Truck(hub, start_time) 
 
    # ensures that package requirements are met O(n) analysis 
    for p in packages: 
        if p.truck1_only: 
            index = packages.index(p) 
            p1 = packages.pop(index) 
            truck1.loadPackage(p) 
        elif p.truck2_only: 
            index = packages.index(p) 
            p1 = packages.pop(index) 
            truck2.loadPackage(p) 

 
 
    # Packages are popped out of the list and passed to the getBestQueue method. 
    # Every package is looked at once. Those that are left over end up in delayed_packages 
    # or recycled_packages. O(n) operation
    while len(packages) > 0: 
        package = packages.pop(0) 
        if (package.address not in delayed_addresses) & (package.deadline == ":"):
            early_packages.append(package)
        # Checks if packages are going to an address on the delayed route (and that don't have a dealine). 
        if (not package.deliverable) or ((package.address in delayed_addresses) and (package.deadline == "EOD")): 
            delayed_packages.append(package) 
        
        else: 
            getBestQueue(package) 
             
    trucks = [truck1, truck2] 
 
    # Combining lists for all leftover packages. 
    extras = recycled_packages + delayed_packages 
 
    best_package = None 
 
    # Ensures that both trucks are full by going over the extras one more time. 
    # This shouldn't have a large impact on time-complexity since at this point 
    # both trucks should be full or almost full. 
    while not isFull(truck1): 
        low = 10000.0 
        for p in extras: 
            if p.truck1_only: 
                index = extras.index(p) 
                break 
            elif p.deliverable: 
 
                test_map = truck1.getTestMap(p) 
                dist = test_map.distance 
                if dist < low: 
                    low = dist 
                    index = extras.index(p) 
                     
        truck1.loadPackage(extras.pop(index))
 
    while not isFull(truck2): 
        low = 10000.0 
        for p in extras: 
            if p.truck2_only: 
                index = extras.index(p) 
                break 
            elif p.deliverable: 
 
                test_map = truck2.getTestMap(p) 
                dist = test_map.map_val 
                if (dist < low) and (p.address not in delayed_addresses): 
                    low = dist 
                    index = extras.index(p) 
        truck2.loadPackage(extras.pop(index)) 
 
    # Records the latest return time in case it is later than the latest delayed package. 
    truck1_return = truck1.getReturnTime() 
    truck2_return = truck2.getReturnTime() 
 
    # If the first truck to return is after the last package delay for the extra route's schedule. 
    if truck1_return >= truck2_return: 
        earliest_return = truck2_return 
    else: 
        earliest_return = truck1_return 
 
    # Sets the latest_delay if necessary. 
    if earliest_return > latest_delay: 
        latest_delay = earliest_return 
 
    new_truck = Truck(hub, latest_delay) 
    new_truck.packages = extras 
    trucks.append(new_truck) 
 
    # Returns list of 3 trucks: Truck 1, Truck 2, and the extra route. 
    return trucks 
 
# Gets total distance for each truck in list passed in and returns the sum.  O(n) for number of trucks.
def getTotalDistance(trucks): 
    distance = 0 
    for truck in trucks: 
        route = truck.getRoute() 
        distance += route.total_distance 
    return distance 
 
schedule = loadTrucks(packages) 
total_distance = getTotalDistance(schedule) 
 
 
# For user queries asking the schedule of the specific package, 
# this method returns the truck that is scheduled to carry that package. O(1)
def getTruckWithPackage(ID): 
    global schedule 
    for truck in schedule: 
        IDs = truck.getPackageIDs() 
        if ID in IDs: 
            return truck 
     
    return None 
 
# Prints all three routes. O(1)
def showRoutes(): 
 
    global schedule 
    global total_distance 
 
 
    truck1 = schedule[0] 
    truck2 = schedule[1] 


    print("Here is the recommended delivery plan: ")
    print()
    print("Truck 1:")
    truck1.printPackageList()
    route = truck1.getRoute()
    print()
    route.printInfo()

    print()
    print()

    print("Truck 2:")
    truck2.printPackageList()
    route = truck2.getRoute()
    print()
    route.printInfo()

    print()
    print()

    # TODO: get the time this route would start.
    print("Extra run for delayed and excess packages:")

    truck = schedule[(len(schedule) - 1)]
    truck.printPackageList()
    route = truck.getRoute()
    print()
    route.printInfo()
    print()
    print("Routes Completed")



    total_distance = getTotalDistance(schedule)
    print("Total distance across all 3 routes: " + str(total_distance) + " miles")
    print()
    print("Please note: ")
    print("- Packages with a deadline will print 'Package ID -ON TIME-' underneath the delivery for an on time delivery.\n Search 'status packages HH:MM:SS' to check timeliness")
    print("- This plan has been optimized to minimize the amount of miles the trucks will drive.")
    print("- Routes produced by this program have accounted for package deadlines.")
    print()
    print("If adjustments have been made to the original route produced by the algorithm to adhere to") 
    print("a deadline, it is noted in the output. Given the relative efficiency of the algorithm, ")
    print("this is only seen in a small percentage of arrangements.")
    

    print()

# This is the main menu where commands for the app are explained.
# It can be summoned by typing the 'help' command. O(1)
def showHelp():
    print("============================================================")
    print("============================================================")
    print("Type commands to see more information.")
    print("Use the 'help' command to see this menu again.")
    print("Exit the program with ^+C")
    print()
    print("Commands can be up to 4 tokens: The command, and one or two additional arguments.")
    print()
    print("   Example: ")
    print()
    print("   'info package 4 08:15:00' or 'status packages HH:MM:SS' ")
    print()
    print()
    print()
    print("============================================================")
    print("Command                      Output")
    print("============================================================")
    print("'help'                       Show list of commands (this menu)")
    print()
    print("'info <args>'                Display information based on arguments.")
    print()
    print("'status <args> <HH:MM:SS>'   Shows the status of a package or truck at a given time.")
    print("                             Sample time format: 08:15:00")
    print("                             Use 'status -v packages <HH:MM:SS>' to see all packages")
    print("                                 with all of their details, including their status.")
    print()                      
    print("  args:   'packages'           Refers to all packages in the schedule.")
    print("          'package <ID>'       Refers to a specific package (ID must be a number).")
    print("          'trucks'             Refers to all truck schedules.")
    print()
    print("============================================================")

# O(1)
def printIntegerError():
    print()
    print("Error parsing ID. Type 'help' to see instructions.")


# This is the method that determines what to do with input by splitting it up into a list of tokens to examine. O(1)
def parseInput(input):
    global schedule
    if input == 'help':
        showHelp()
    else:
        # split command by spaces
        tokens = input.split(" ")
        if len(tokens) <= 1:
            print("Unrecognized command. Type 'help' to see a list of available commands.")
            return
        else:
            cmd = tokens[0]
            arg = tokens[1]
            if cmd == 'info':
                if arg == 'packages':
                    for p in package_master_list:
                        p.printInfo()
                elif arg == 'package':
                    # Attempt to parse the expected integer.
                    try:
                        ID = int(tokens[2])

                        # Using hash function to find information by package ID
                        package = packages_by_id[ID]
                        package.printInfo()
                    
                    # Catch exception to avoid crash
                    except:
                        printIntegerError()
                        return
                elif (arg == 'trucks') or (arg == 'truck'):
                    showRoutes()
                    return
            elif cmd == 'status':
                # The time argument should always be the last argument in the command.
                time_str = tokens[(len(tokens) - 1)]

                # Attmpet to read the time input, catch in case of formatting errors.
                try:
                    new_dt = datetime.datetime.strptime(str(time_str), "%H:%M:%S")
                    time_arg = new_dt.time()
                except:
                    print("Error parsing time. Please check time format.")
                    return

                # Shows the status of all packages at a given time.
                if arg == 'packages':
                    for truck in schedule:
                        truck.printStatusAtTime(time_arg)
                    return
                
                # Targets specific package and prints all information on it.
                elif arg == 'package':
                    try:
                        ID = int(tokens[2])

                        truck = getTruckWithPackage(ID)
                        truck.printPackageStatusVerbose(ID, time_arg)
                        return
                    except:
                        printIntegerError()
                        return
                # Verbose 0 prints detailed info on all packages.
                elif arg == '-v':
                    for truck in schedule:
                        for package in truck.packages:
                            truck.printPackageStatusVerbose(package, time_arg)
            else:
                print("Unrecognized command. Type 'help' to see a list of available commands.")
                return

# Print routes and then menu
showRoutes()

print()

showHelp()

print()

# Main loop
while True:
    try:
        usr_input = input("Enter command: ")
        parseInput(usr_input)
    # Closes on console interrupt.
    except KeyboardInterrupt:
        break

print("Closing...")

