"""
Timothy Verthein, S#001251514
C950 - Data Structures and Algorithms II Objective Assessment
WGUPS Routing Program

FILES:

wgups.py - Objects and classes
main.py  - Main program (run main.py)
distances.csv - formatted distance table
packages.csv  - formatted package table

This custom Python module uses an object-oriented programming model, and contains
classes and objects to help solve the Vehicle Routing Problem. It was created using Python 3.7
in Visual Studio Code.

The objects in this model represent Packages, Locations, Trucks, and Routes, as well as 
supplemental classes such as Vertex() and Map() assist in creating data structures.

The main.py script uses this module to solve the WGUPS prompt.

PROBLEM SUMMARY:

The purpose of this modul is to help create/adapt an algorithm to find an efficient delivery
route for a set of packages. These packages have certain constraints, such as deadlines,
delays, grouping requirements, and truck requirements. This is a version of a programming
problem known as the Vehicle Routing Problem, which is akin to the more well-known 
Traveling Salesman Problem. This problem is considered NP-hard, where the time-complexity to
solve it is known to be O(n!). Most solutions, like this one, deliver a an approximation
that isn't the most optimal, but can be done quickly by a computer to find routes for larger
sets of data.

Class breakdown:

    Package():
        Contains information about the package, including all provided details
        Packages are stored in a list and a dictionary (using the package ID as a key) in main.py
        With this solution the hash function will return a reference to a Package object through which
            we can access any or all of the information.

    Location():
        Edge of the graph
        Contains information about the location, including name and address
        Contains information on connections it has to all other locations

    Vertex():
        Contains two locations and a weight, representing the distance between those two locations.

    Map():
        Takes a set of locations and performs the nearest-neighbor algorithm to come up with the route.
    
    Route():
        Takes a map and a starting time to provide a schedule.
        Also takes the set of packages to ensure that the route delivers them all on time.

    Truck():
        Takes a 'hub' location and start time, and begins with an empty list of packages.
        Packages are added/removed from the list (loading packages onto the truck)
        Trucks turn the list of packages into a list of locations to create a Map and a Route.





"""

import datetime

"""
The Vertex class represents the vertex of a graph.

Its only function is to connect two nodes by a weight. In this case, the nodes
are Locations on our delivery list, and the weight is the distance between the 
two locations.

Instances of the Vertex class are all created during loading and stored in the
Location class, in a way that each Location knows how far away it is from every
other location. The space-complexity of the program relies on the complete graph 
constituting the map of the city, which is described as O((n(n-1))/2)
"""
class Vertex():
    def __init__(self, node1, node2, weight):
        # Nodes is the "nodes" on the graph - each vertex connects two nodes.
        # node1 and node2 are Location objects in this case.
        self.nodes = [node1, node2]

        # The weight is the distance between the two locations.
        self.weight = weight

    # Returns which node this vertex connects to.
    def getConnectingNode(self, node):
        # Comparing names since comparing variable references can get buggy and strings are more reliable
        name = node.name
        if name == self.nodes[0].name:
            return self.nodes[1]
        elif name == self.nodes[1].name:
            return self.nodes[0]
        else:
            return None

    # prints information on this vertex
    def printInfo(self):
        name1 = self.nodes[0].name
        name2 = self.nodes[1].name
        distance = self.weight
        print(name1 + " | " + name2 + ": " + str(distance))

"""
The Location() class holds a lot of information for this program. Each location has information about itself,
information of all other locations relative to itself (the distance between self and other Locations), as well as
static information about all of the locations.

After the input file has been read, every location should have a connection to another location with a Vertex().
The goal here is to make it so that any set or subset of Location objects can be treated as a complete graph.
Since the Map() class contains the core algorithm, creating a self-adjusting data structure once vastly improves 
the time-complexity over constructing a graph every time we wanted to create a Map based on a subset of locations.
"""
#graph is built once each addition is O(1)
class Location():
    # These dictionaries are static, so any location can be accessed by its name or address through the class itself.
    locations_by_name = {}
    locations_by_address = {}
    def __init__(self, name, address, zip):
        self.name = name
        self.address = address
        self.zip = zip

        # list of packages addressed to this location
        self.packages = []
        
        # { Name : Path } / { Address : Path }
        # Quickly get the distance between this location and another location
        # This is different from the class variables, since each location will have a unique set of
        # vertices connecting to other locations,
        self.vertices_by_name = {}
        self.vertices_by_address = {}
        
        Location.locations_by_name[self.name] = self

        Location.locations_by_address[self.address] = self

        # { Distance from This Location : [Location(s)] }
        # Quickly get closest location based on the sorted distance array.
        # They are stored in lists and appended to account for some locations
        # having equidistant connections.
        self.vertices_by_distance = {}

    
    # When the distance table is read, it is recorded and sorted in many ways.
    # Putting the vertices in dictionaries by name and address helps for quick reference
    # in a variety of contexts.

    # All of these vertices are created in the Location class, using that instance as one of the nodes.
    # Adding vertex is O(1)
    def addConnection(self, node, weight):
        w = float(weight)
        w = round(w, 1)
        name = node.name
        address = node.address
        v = Vertex(self, node, w)
        self.vertices_by_name[name] = v
        self.vertices_by_address[address] = v
        
        # There will most certainly be collisions when hashing by distance, so each key will
        # point to a list of vertices to avoid those.
        if w not in self.vertices_by_distance:
            self.vertices_by_distance[w] = []
            self.vertices_by_distance[w].append(v)
            
        else:
            self.vertices_by_distance[w].append(v)
        
    # Returns the vertex connecting self and the location passed in O(1)
    def getConnectingVertex(self, loc):
        return self.vertices_by_address[loc.address]

    # easiest way to get distance from this node to another node O(1)
    def getDistance(self, node):
        name = node.name
        return self.vertices_by_name[name].weight
    
    # Gets the shortest connection (vertex) between self and the list of locations; O(1) should always be first item.
    def getShortestVertex(self, locations):
        sorted_locs = self.sortConnectionsByDistance(locations)
        return sorted_locs[0]

    # Sorts the list of locations passed in by their distance to itself.
    # Using the Python sorted() method this operation is done in O(n log(n)) time, where
    # n is the number of locations passed in. 
    def sortConnectionsByDistance(self, other_locations):
        distances = []
        output = []
        for loc in other_locations:
            distances.append(self.getDistance(loc))
        distances = sorted(distances)
        for dist in distances:
            verts = self.vertices_by_distance[dist]
            for i in verts:
                if not(i in output) and (i.nodes[0] in other_locations or i.nodes[1] in other_locations):
                    output.append(i)
        return output

"""
The Package class takes the raw input from the packages.csv file and creates
an object out of it. It contains all information provided and converts items from the
note and deadline to usable information.
"""
#sorting through the list of packages is in the CSV file to create a class of packages takes O(n) 
#each packages needs to be traveresed once.
class Package():
    packages_by_id = {}
    def __init__(self, id, address, zip, deadline, city, state, mass, note):
        self.id = id
        
        self.address = address
        self.city = city
        self.state = state
        self.zip = zip
        self.mass = mass
        self.note = note
        self.delay = None
        

        if not deadline.strip() == "EOD":
            x = str(deadline).strip()
            dt = datetime.datetime.strptime(x, "%H:%M %p")
            self.deadline = dt.time()
            
        else:
            self.deadline = deadline

        self.deliverable = True

        self.truck1_only = False
        self.truck2_only = False
        self.truck1_also = False
        self.truck2_also = False

        self.delay = None

        self.deliver_with_id = []

        self.status = "Ready to deliver"

        # This series of if statements parse the String representing the note left with the package
        # to add data to the Package object. We look for delays, deadlines, and truck constraints.
        # This first statement checks to see if the package was delayed and parses the time it was delayed.
        if "Delayed" in note:
            
            self.deliverable = False
            words = note.split(' ')

            for word in words:
                if ':' in word:
                    index = words.index(word)
                    time_string = word
                    time_string += " am"

            dt = datetime.datetime.strptime(time_string, "%H:%M %p")
            self.delay = dt.time()
            self.status = "Delayed until " + str(self.delay)


        elif (note.strip() == "Can only be on truck 1"):
            self.truck1_only = True
        elif ((address.strip() == "1330 2100 S") and (mass.strip() == "2")):
            self.truck1_also = True
        elif ((address.strip() == "3365 S 900 W") and (mass.strip() == "1")):
            self.truck2_also = True
        elif note.strip() == "Can only be on truck 2":
            self.truck2_only = True
        elif "Must be delivered with" in note:
            note_padding = 22
            note_length = len(note)
            nums_str = note[note_padding:note_length]
            nums = nums_str.split(",")
            for n in nums:
                package_id = n.strip()
                self.deliver_with_id.append(int(package_id))
        else:
            self.status = "Waiting for Delivery"

        Package.packages_by_id[self.id] = self
        
    def setDestination(self, destination):
        self.destination = destination

    # The constraints in this scenario that would require a package to 
    def priority_assignment(self):
        return self.truck1_only or self.truck2_only or (len(self.deliver_with_id) > 0)

    def printInfo(self):
        print("")
        print("====================================")
        print("Package ID..........." + str(self.id))
        print("Destination.........." + str(self.address) + ", " + self.city + ", " + self.state)
        print("Postal Code.........." + str(self.zip))
        print("Mass (KG)............" + str(self.mass))
        print("Delivery Deadline...." + str(self.deadline))
        print("Delivery Status......" + self.status)
        if not self.note == '':
             print("\nSpecial Note: \n" + self.note)
             print("====================================")
             print("")
            
        else:
           print("\nNo special note")
        
"""
The Truck object contains a list of packages to deliver as well as a scheduled start time. 
This information can be used to create a Map and a Route.
"""
class Truck():
    max_packages = 16
    speed = 18.0

    def __init__(self, hub, start_time):
        self.packages = []
        self.address_list = []
        self.hub = hub
        self.full = False
        self.start_time = start_time


    # Returns a Route() with the information specific to this truck. O(1)
    def getRoute(self):
        r = Route(self.getMap(), self.packages, self.start_time)
        return r

    # Returns the time the truck returns to the hub from its delivery route.
    # This information is used to help determine when the extra run can depart. O(1)
    def getReturnTime(self):
        r = self.getRoute()
        distance = Route.calculateDistance(r.route)
        return Route.getTimeFromDistance(distance, self.start_time)

    # Replaces the worst package with the package passed in. Also returns the package removed O(1)
    def swapWithWorstPackage(self, new_package):
        worst_package = self.getWorstPackage()
        index = self.packages.index(worst_package)
        pop = self.packages.pop(index)

        # Remove this address from the address list
        if not (pop.address not in self.address_list):
            self.address_list.remove(pop.address)
        self.loadPackage(new_package)
        return pop

    # Returns a boolean to find if swapping this package with the
    # package with the worst impact will have a positive effect on
    # map value (average of upper and lower bounds). This is used
    # when evaluating full trucks to see if a better set is available. O(1)
    def swapImprovesRoute(self, new_package):
        dt = datetime.datetime.strptime("8:00 am", "%H:%M %p")
        start_time = dt.time()

        worst_package = self.getWorstPackage()

        if worst_package.priority_assignment:
            return False


        original_map = self.getMap()
        test_truck = Truck(self.hub)

        test_truck.packages = self.packages.copy()

        test_truck.packages.remove(worst_package)
        test_truck.loadPackage(new_package)
        
        test_map = test_truck.getMap()

        return test_map.distance < original_map.distance


    # Returns the package has the worst impact on the route. O(n)
    def getWorstPackage(self):
        test_truck = Truck(self.hub, self.start_time)

        address_count = {}
        og_packages = self.packages.copy()
        worst_package = None

        # Lowest score is initialized to be far higher than anything possible generated by the problem
        lowest_score = 1000000.0

        # If we are looking for a single package that has the worst impact on the route, we can immediately rule
        # out any packages that are being delivered with another package to the same address.
        # This loop is meant to count how many packages are being delivered to each address so we can determine
        # which packages are currently scheduled to be delivered alone.
        for p in self.packages:
            if p.address not in address_count:
                address_count[p.address] = 0
            
            address_count[p.address] += 1

        solo_packages = []
        for p in self.packages:
            if address_count[p.address] == 1:
                solo_packages.append(p)

        for p in solo_packages:
            test_truck.packages = self.packages.copy()
            test_truck.packages.remove(p)

            m = test_truck.getMap()
            if (m.distance < lowest_score) and (not p.priority_assignment()):
                lowest_score = m.distance
                worst_package = p

        # If there are no single packages being delivered to an address, there is no worst package.
        # Any package that doesn't have a constraint will do.
        if worst_package == None:
            for p in self.packages:
                if not p.priority_assignment():
                    return p
                    
        return worst_package

    # Returns a map based on this trucks hub and set of delivery locations. O(1)
    def getMap(self):
        return Map(self.hub, self.getLocationSet())

    # This method returns the potential route this truck would have if it had this package in addition
    # to its current packages. This is used to evaluate which truck the package will have the least impact on.
    # Creating a new map has a runtime of O(n log(n)).
    def getTestMap(self, package):
        test_truck = Truck(self.hub, self.start_time)
        test_truck.packages = self.packages.copy()
        test_truck.packages.append(package)

        return test_truck.getMap()

    # Gets the set of locations to deliver every package.
    def getLocationSet(self):
        locs = [self.hub]
        if len(self.packages) > 0:
            for p in self.packages:
                loc = Location.locations_by_address[p.address]
                # Prevents duplicates due to multiple packages going to the same address
                if loc not in locs:
                    locs.append(loc)
        return locs
    
    # Returns whether the truck is at maximum capacity
    def isFull(self):
        b = (len(self.packages) >= Truck.max_packages)
        return b
    
    # This method should be used to load the packages
    def loadPackage(self, package):
        self.packages.append(package)
        if package.address not in self.address_list:
            self.address_list.append(package.address)
        self.full = self.isFull()

    # Returns a list of integers representing each package's ID on this truck for human readability.
    def getPackageIDs(self):
        ls = []
        for p in self.packages:
            ls.append(p.id)
        return ls

    # Prints a list of the Package ID's for the packages on this truck. O(n)
    def printPackageList(self):
        package_ids = []

        for p in self.packages:
            package_ids.append(p.id)

        package_ids = sorted(package_ids)
        reversed(package_ids)
        print("Package IDs:")
        message = ""
        while len(package_ids) > 0:
            message += str(package_ids.pop())
            if len(package_ids) > 0:
                message += ", "

        print(message)
        print()

    # These methods are for printing information in the console.
    # This prints the status of this truck at a given time. Up to O(n) if all routes are printed
    def printStatusAtTime(self, time):
        route = self.getRoute()
        for package in self.packages:
            s = route.getStatusAtTime(package, time)
            o = route.getStatusOnTime(package, time)
            print(s)
            print(o)
   

    # This prints the status of a specific package at a given time. O(1)
    def printPackageStatusAtTime(self, package, time):
        route = self.getRoute()
        s = route.getStatusAtTime(package, time)
        print(s)

    # This prints all of the package information, including its status at the given time. O(1)
    def printPackageStatusVerbose(self, package, time):
        route = self.getRoute()
        s = route.getStatusAtTime(package, time)
        package.status = s
        package.printInfo()


"""
The Map() class contains the core algorithm. It takes a set of locations as well as the hub location
and performs the Nearest Neighbor algorithm to come up with a valid route. From the list of locations,
the map creates data representing the route, the list of addresses that the route visits, the set 
of locations that constitute the route, as well as the location that was passed in marked as the hub. 

The data is stored in a way that each location knows where every other location is relative to it.
Therefore any subset of locations, such as the list passed in to create a Map, can already be treated 
as a complete graph. Since Map() instances are created and destroyed so many times throughout loading the
packages, having the locations constitute a graph implicitly takes a great load off of the core algorithm.
 
"""
class Map():
    # h = hub location object, locations = list of locations to build map from
    def __init__(self, h, locations):
        self.hub = h
        # hash the locations behind an array index
        if not self.hub in locations:
            locations.append(self.hub)

        self.address_list = []

        for loc in locations:
            self.address_list.append(loc.address)

        self.locations = locations
        unvisited_locations = locations

        while self.hub in unvisited_locations:
            unvisited_locations.remove(self.hub)
            
        nn_distance = 0

        # CORE ALGORITHM O(n log(n)). 
        h = self.hub
        current_node = h
        self.nn_traversal = []
        while len(unvisited_locations) > 0:
            self.nn_traversal.append(current_node)
            next_vertex = current_node.getShortestVertex(unvisited_locations)
            next_index = unvisited_locations.index(next_vertex.getConnectingNode(current_node))
            next_node = unvisited_locations.pop(next_index)
            nn_distance += current_node.getDistance(next_node)
            current_node = next_node
        
        nn_distance += current_node.getDistance(h)
        
        # This is the total distance of the route generated by the algorithm.
        self.distance = nn_distance

"""
The Route() class takes a start time, a Map() which contains information on the route, and a corresponding set of packages.

This class creates a schedule for the Truck. It also has many supporting methods to help calculate
time and distance, as well as to check that all packages are delivered on time.
"""
class Route():
    # This variable relies on the max packages of the trucks being used.
    # Modifying the truck's value will adapt the route.
    max_packages = Truck.max_packages

    # init takes the hub location as an argument as it is the default stop and end point to all routes
    def __init__(self, m, packages, start_time):
        self.map = m
        self.hub = m.hub
        self.packages = packages
        self.route = self.map.nn_traversal
        self.route_vertices = []
        self.total_distance = 0.0
        self.start_time = start_time

        self.adjustments_made = False

        self.valid = True
        
        
        self.route.append(self.hub)

        # Checks each location to see that the package heading there meets any deadlines O(n)
        if len(self.route) > 0:
            for location in self.route:
                # checkDeliveryTimes() calls teakRoute() if it finds a package that is late
                self.checkDeliveryTimes(location)
            
        self.setRouteVertices()

    # Check the time this package is scheduled to be delivered as a datetime.time() datatype O(1)
    def getDeliveryTime(self, package):
        if package.address not in self.map.address_list:
            return None
            
        else:
            location = Location.locations_by_address[package.address]
            distance_to_stop = self.getDistanceToStop(location)
            delivery_time = Route.getTimeFromDistance(distance_to_stop, self.start_time)
            return delivery_time

    
           

    # Returns a string representing a package's delivery status at a given time based on this route's schedule.
    # A package can either be delivered, en route, or waiting to be loaded. Up to O(n) if all packages called
    def getStatusAtTime(self, package, time):
        ID = str(package.id)
        address = package.address
        time_str = str(time)
        on_time = str(package.deadline)

        

        # get time representing the scheduled delivery
        scheduled_delivery = self.getDeliveryTime(package)
        

        # Compare the time passed in to the start time of this route
        if time < self.start_time:
            return "Package " + ID + " is waiting to be loaded."
        # If it's between the start time and the scheduled delivery it is en route. 

        if time >= scheduled_delivery:
            return "Package " + ID + " delivered to " + address + " at "  + str(scheduled_delivery)
        # If it isn't en route or waiting to be loaded then it has been delivered.
        else:
            return "Package " + ID + " is currently en route and scheduled to be delivered at " + str(scheduled_delivery)
        #O(n) if latest time called then all deliveries would be printed
    def getStatusOnTime(self, package, time):
        ID = str(package.id)
        address = package.address
        time_str = str(time)
        on_time = str(package.deadline)

        

        # get time representing the scheduled delivery
        scheduled_delivery = self.getDeliveryTime(package)     
        
        if on_time == "EOD":
           return ''
        if (str(scheduled_delivery) <= str(on_time)) & (time >= scheduled_delivery) :
            return "Package " + ID + " -ON TIME-\n"
            
    # Checks all packages to ensure that they are delivered on time.
    # From some tests run on this program it seems that only a small percentage of arrangements deliver 
    # packages past their deadlines. This method is intended to catch those instances, adjust the route
    # to fit the schedule, and mark this route if it makes the adjustments to display in the output. O(n)
    def checkDeliveryTimes(self, location):
        start_time = self.start_time
        for p in self.packages:
            if p.address == location.address and p.deadline != "EOD":
                distance = self.getDistanceToStop(location)
                delivery_time = Route.getTimeFromDistance(distance, start_time)

                # If this route hasn't been adjusted, the first step should be to reverse
                # the route since it's circular, and the location may appear in the first half
                # of the route and solve the problem simply.
                if (not self.adjustments_made) and (delivery_time > p.deadline):
                   self.route.reverse()
                   self.adjustments_made = True
                
                while delivery_time > p.deadline:
                    # The tweak route is called while this address is 
                    self.tweakRoute(location)
                    distance = self.getDistanceToStop(location)
                    delivery_time = Route.getTimeFromDistance(distance, start_time)
                
    # Tweaks are made to ensure every package is delivered on time. This can sometimes mess up how efficient
    # the route is, but since packages are loaded into trucks based on their impact on the route, those
    # edge cases haven't appeared in any results thusfar. Since this check is an inherent part of the route creation,
    # any route that is output by the program has already been checked and adjusted to ensure that all of the 
    # packages have been delivered. If adjustments were made to fit the schedule, it will be noted in the output.
    #Both swapped packages are ID'd in other operations O(1) event
    def tweakRoute(self, location):
        # Swaps the problem location with the one before it in to make it an earlier delivery.
        index = self.route.index(location)
        self.route.insert(index - 1, self.route.pop(index))
        self.setRouteVertices()

    # The Route is a list of locations, and this method sets a corresponding set of Vertices
    # with which we can determine distances. Up to O(n) gets less after each delivery. 
    def setRouteVertices(self):
        current_route = []
        for i in range(0, (len(self.route) - 1)):
            current_stop = self.route[i]
            next_stop = self.route[(i+1)]

            current_route.append(current_stop.getConnectingVertex(next_stop))

        self.setTotalDistance()
        self.route_vertices = current_route

    # Returns the distance to a certains top along the route. Up to O(n)
    def getDistanceToStop(self, stop):
        output = 0
        for v in self.route_vertices:
            output += v.weight
            if stop in v.nodes:
                break
        return output
        
    # Simple way of calculating the distance of this route.    
    def setTotalDistance(self):
        r = self.route
        self.total_distance = Route.calculateDistance(r)

    # Calculates total distance between a list of locations (in the order that they are listed). O(n)
    @staticmethod
    def calculateDistance(locations):
        max_index = len(locations) - 1
        x = 0
        for i in range(0, max_index):
            j = i+1
            loc1 = locations[i]
            loc2 = locations[j]
            x += loc1.getDistance(loc2)
        return x

    # Converts distance to a length of time using the truck's given speed (stored in a static variable in the Truck class)
    @staticmethod
    def distanceToSeconds(distance):
        hours = distance / Truck.speed
        return int(hours * 3600)

    # Returns the time a truck would reach a certain distance given its starting time.
    @staticmethod
    def getTimeFromDistance(distance, start_time):
        route_in_seconds = Route.distanceToSeconds(distance)
        new_dt = datetime.datetime.strptime(str(start_time), "%H:%M:%S")
        updated_dt = new_dt + datetime.timedelta(seconds=route_in_seconds)
        return updated_dt.time()

    # This method prints out the route in the form of a schedule. Up to O(n)
    def printInfo(self):
        if len(self.route_vertices) > 0:
            print("Route info: \n")
            print("Departs from " + self.hub.name + " at " + str(self.start_time))
            current_stop = self.hub
            start_time = self.start_time
            current_time = start_time
            total_distance = 0
            name = self.hub.name
            
            # Prints information on each Vertex in the route.
            for v in self.route_vertices:
                next_stop = v.getConnectingNode(current_stop)
                
                total_distance += v.weight

                # Include scheduled delivery time in report by converting total distance
                # at this point in the route to total time passed.
                current_time = Route.getTimeFromDistance(total_distance, start_time)
                timestamp = str(current_time)
                name = next_stop.name
                current_stop = next_stop
                
                if not name == self.hub.name:
                    print(timestamp + ": Stop at " + name  + " for delivery.")
                   
                else:
                    print("Return to " + name + " at " + timestamp)
                
            # self.adjustments_made indicates whether the route was modified to meet a package deadline.
            if  self.adjustments_made:
                print("\nTotal distance:    " + str(self.total_distance) + " miles (Adjustments made from original route to fit schedule)")

               
            else:
                 print("\nTotal distance:    " + str(self.total_distance) + " miles")