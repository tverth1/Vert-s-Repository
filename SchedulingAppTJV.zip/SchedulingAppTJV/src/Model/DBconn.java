/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;

/**
 *connection and method setup
 * TJV 
 */
public class DBconn {
    
    private static Connection conn;
    private final static String JDBC_DRIVER = "com.mysql.jdbc.Driver";
    private final static String DBNAME = "U06ZEq";
    private final static String URL = "jdbc:mysql://3.227.166.251/" + DBNAME;
    private final static String DBUSER = "U06ZEq";
    private final static String DBPASS = "53688911019";
    

    public DBconn()
    {
        
    }
    public static void init()
    {
        try
        {
            //send driver
            Class.forName("com.mysql.jdbc.Driver");
            //open a connection
            System.out.println("Connecting...");
            conn = DriverManager.getConnection(URL, DBUSER, DBPASS);
        }
        catch (ClassNotFoundException notfound)
        {
            System.out.println("Not Found, Please add MySQL library.");
            notfound.printStackTrace();
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
    
    public static Connection getConn()
    {
        return conn;
    }
    
    public static void closeConn()
    {
        try
        {
            conn.close();
        }
        catch (Exception c)
        {
            c.printStackTrace();
        }
        finally
        {
            System.out.println("Connection Ended.");
        }
    }
    
    
    public static Appointment getSelectedAppt(String statement, int appointmentId){
        Appointment selectA = new Appointment();
        try{
            PreparedStatement ps = conn.prepareStatement(statement);
            ps.setInt(1, appointmentId);
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()){
            } else {
                selectA.setAppointmentId(rs.getInt("appointmentId"));
                selectA.setTitle(rs.getString("title"));
                selectA.setDescription(rs.getString("description"));
                selectA.setLocation(rs.getString("location"));
                selectA.setContact(rs.getString("contact"));
                selectA.setType(rs.getString("type"));
                selectA.setUrl(rs.getString("url"));
                selectA.setStart(convertFromUTC(rs.getTimestamp("start")));
                selectA.setEnd(convertFromUTC(rs.getTimestamp("end")));
                selectA.setCreateDate(rs.getTimestamp("createDate"));
                selectA.setCreatedBy(rs.getString("createdBy"));
                selectA.setLastUpdate(rs.getTimestamp("lastUpdate"));
                selectA.setLastUpdateBy(rs.getString("lastUpdateBy"));
                selectA.setUserId(rs.getInt("userId"));
                selectA.setCustomerId(rs.getInt("customerId"));
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        return selectA;
    }
    public static Timestamp convertFromUTC(Timestamp t){
        ZonedDateTime zonedstart = t.toLocalDateTime().atZone(ZoneId.of("UTC"));
             ZonedDateTime startSd = zonedstart.withZoneSameInstant(ZoneId.systemDefault());
             Timestamp start = Timestamp.valueOf(startSd.toLocalDateTime());
             return start;
        
    }
    public static Timestamp convertToUTC (Timestamp t) {
        ZonedDateTime zonedstart = t.toLocalDateTime().atZone(ZoneId.systemDefault());
             ZonedDateTime startSd = zonedstart.withZoneSameInstant(ZoneId.of("UTC"));
             Timestamp start = Timestamp.valueOf(startSd.toLocalDateTime());
             return start;
    }     
            
    public static ArrayList<Appointment> getAppointments(String statement){
        ArrayList<Appointment> lista = new ArrayList();
        try{
            PreparedStatement ps = conn.prepareStatement(statement);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){
                Appointment a = new Appointment();
                a.setAppointmentId(rs.getInt("appointmentId"));
                a.setTitle(rs.getString("title"));
                a.setDescription(rs.getString("description"));
                a.setLocation(rs.getString("location"));
                a.setContact(rs.getString("contact"));
                a.setType(rs.getString("type"));
                a.setUrl(rs.getString("url"));
                a.setStart(convertFromUTC(rs.getTimestamp("start")));
                a.setEnd(convertFromUTC(rs.getTimestamp("end")));
                a.setCreateDate(rs.getTimestamp("createDate"));
                a.setCreatedBy(rs.getString("createdBy"));
                a.setLastUpdate(rs.getTimestamp("lastUpdate"));
                a.setLastUpdateBy(rs.getString("lastUpdateBy"));
                a.setUserId(rs.getInt("userId"));
                a.setCustomerId(rs.getInt("customerId"));
                lista.add(a);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        return lista;
    }
    
    public static ArrayList<Customer> getCustomers(String statement){
        ArrayList<Customer> listc = new ArrayList();
        try{
            PreparedStatement ps = DBconn.getConn().prepareStatement(statement);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){
                Customer c = new Customer();
                c.setCustomerId(rs.getInt("customerId"));
                c.setCustomerName(rs.getString("customerName"));
                c.setAddressId(rs.getInt("addressId"));
                c.setCreateDate(rs.getTimestamp("createDate"));
                c.setCreatedBy(rs.getString("createdBy"));
                c.setLastUpdate(rs.getTimestamp("lastUpdate"));
                c.setLastUpdateBy(rs.getString("lastUpdateBy"));
                listc.add(c);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        return listc;
    }
    
    public static void updateCustomer(Customer customer){
        try{
            String stmt = "UPDATE U06ZEq.customer SET customerName=?, addressId=? WHERE customerId=?";
            PreparedStatement ps = DBconn.getConn().prepareStatement(stmt);
            ps.setString(1, customer.getCustomerName());
            ps.setInt(2, customer.getAddressId());
            ps.setInt(3, customer.getCustomerId());
            ps.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    public static void insertCity(Customer customer){
        try{
            String stmt = "INSERT INTO U06ZEq.city (city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(stmt);
            ps.setString(1, customer.getCity());
            ps.setInt(2, customer.getCountryId());
            ps.setTimestamp(3, customer.getCreateDate());
            ps.setString(4, customer.getCreatedBy());
            ps.setTimestamp(5, customer.getLastUpdate());
            ps.setString(6, customer.getLastUpdateBy());
            ps.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    public static ArrayList<Customer> getCountry(){
        ArrayList<Customer> listcntry = new ArrayList();
        try{
            String stmt = "SELECT * FROM U06ZEq.country";
            PreparedStatement ps = conn.prepareStatement(stmt);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Customer customer = new Customer();
                customer.setCountry(rs.getString("country"));
                customer.setCountryId(rs.getInt("countryId"));
                listcntry.add(customer);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        
        return listcntry;
    }
    //help with simpler insert statements here https://stackoverflow.com/questions/17207088/how-to-use-java-variable-to-insert-values-to-mysql-table
    public static void insertCountry(Customer customer){
        try{
            String stmt = "INSERT INTO U06ZEq.country (country, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(stmt);
            ps.setString(1, customer.getCountry());
            ps.setTimestamp(2, customer.getCreateDate());
            ps.setString(3, customer.getCreatedBy());
            ps.setTimestamp(4, customer.getLastUpdate());
            ps.setString(5, customer.getLastUpdateBy());
            ps.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    public static void insertAddress(Customer customer){
        try{
            String stmt = "INSERT INTO U06ZEq.address (address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?,?,?,?,?)";
            PreparedStatement ps = conn.prepareStatement(stmt);
            ps.setString(1, customer.getAddress());
            ps.setString(2, customer.getAddress2());
            ps.setInt(3, customer.getCityId());
            ps.setString(4, customer.getPostalCode());
            ps.setString(5, customer.getPhone());
            ps.setTimestamp(6, customer.getCreateDate());
            ps.setString(7, customer.getCreatedBy());
            ps.setTimestamp(8, customer.getLastUpdate());
            ps.setString(9, customer.getLastUpdateBy());
            ps.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    
    public static ArrayList<Customer> getCity(){
        ArrayList<Customer> listcity = new ArrayList();
        try{
            String stmt = "SELECT * FROM U06ZEq.city";
            PreparedStatement ps = conn.prepareStatement(stmt);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Customer customer = new Customer();
                customer.setCity(rs.getString("city"));
                customer.setCityId(rs.getInt("cityId"));
                customer.setCountryId(rs.getInt("countryId"));
                listcity.add(customer);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        
        return listcity;
    }
    
    public static ArrayList<Customer> getAddress(){
        ArrayList<Customer> listadd = new ArrayList();
        try{
            String stmt = "SELECT * FROM U06ZEq.address";
            PreparedStatement ps = conn.prepareStatement(stmt);
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                Customer customer = new Customer();
                customer.setAddress(rs.getString("address"));
                customer.setAddress2(rs.getString("address2"));
                customer.setPhone(rs.getString("phone"));
                customer.setPostalCode(rs.getString("postalCode"));
                customer.setAddressId(rs.getInt("addressId"));
                customer.setCityId(rs.getInt("cityId"));
                listadd.add(customer);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        
        return listadd;
    }
}
