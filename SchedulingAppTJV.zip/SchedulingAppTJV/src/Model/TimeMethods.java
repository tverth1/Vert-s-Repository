/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.util.Calendar;
import java.time.LocalTime;

import java.sql.Timestamp;
import java.time.LocalDate;

public class TimeMethods {
    
   public static Timestamp getTimestamp(LocalDate date, String time, String apPicker){
        
        String stamp = "";
        String dd = date.toString();
                
        String[] solToken = time.split(":");
        
        int hr = Integer.parseInt(solToken[0]);
        int min = Integer.parseInt(solToken[1]);
        
        // special case 12:00AM = 00:00:00
        if (!apPicker.equals("am") || hr != 0)
            
            if (!apPicker.equals("pm") || hr != 12)
                
                if ((!apPicker.equals("am") || hr < 1) || hr > 9)
                    
                    if ((!apPicker.equals("pm") || hr < 10) || hr > 11)
                        
                        if ((!apPicker.equals("pm") || hr < 1) || hr > 11){
                            
                stamp = dd + " " + hr + ":" + min + ":00.0";
            }
            else{ // 1:00PM - 11:00PM (13:00 - 23:00)
                hr = hr + 12;
                stamp = dd + " " + hr + ":" + min + ":00.0";
            }
        else {
                // 10:00AM - 11:00AM
                stamp = dd + " " + hr + ":" + min + ":00.0";
        }
        else {
            // 1:00AM - 9:00AM
            stamp = dd + " 0" + hr + ":" + min + ":00.0";
        }
        else {
            stamp = dd + " " + hr + ":" + min + ":00.0";
        }
        // unique case 12:00PM = 12:00:00
        else {
            stamp = dd + " 00" + ":" + min + ":00.0";
        }
        
        return Timestamp.valueOf(stamp);
    }
    
    
    public static int dayToken(Timestamp timestamp){
        // Break timestamp into tokens
        String[] solToken = timestamp.toString().split(" ");
        
        // tokens[0] is date stamp
        String date = solToken[0];
              
        return Integer.parseInt(date.substring(8));
    }
    
    public static int weekToken(Timestamp timestamp){
        // Break timestamp into tokens
        String[] solToken = timestamp.toString().split(" ");
        
        // tokens[0] is date stamp
        String date = solToken[0];
        int yr = Integer.parseInt(date.substring(0, 4));
        int mo = Integer.parseInt(date.substring(5, 7));
        int dd = Integer.parseInt(date.substring(8));
        
        
        // Create calendar instance and set to tokens[0]
        Calendar cal = Calendar.getInstance();
        cal.setFirstDayOfWeek(Calendar.WEDNESDAY);
        cal.set(yr, mo, dd);
        
        return cal.get(Calendar.WEEK_OF_MONTH);
    }
     public static int monthToken(Timestamp timestamp){
        //this breaks down the the entire timestamp into tokens. Location 5-7 in the 
        //stamp is where the Month is. 
        String[] solToken = timestamp.toString().split(" ");
        String date = solToken[0];
        String month = date.substring(5, 7);
        
        return Integer.parseInt(month);
    }
    
    public static LocalTime timeToken(Timestamp timestamp){
        // Break timestamp into tokens
        String[] solToken = timestamp.toString().split(" ");
        
        // tokens[0] is date stamp
        String date = solToken[1];
                
        return LocalTime.parse(date);
    }
    
    public static int hourToken(Timestamp timestamp){
        //  Break timestamp into tokens
        String[] solToken = timestamp.toString().split(" ");
        String[] time = solToken[1].split(":"); //where the split will happen
        int hour = Integer.parseInt(time[0]); 
        
        return hour;
        
    }
    
     
    
}
