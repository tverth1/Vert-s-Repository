/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Timestamp;
import java.sql.SQLException;
import java.sql.ResultSet;



public class User 
{
    
    
    private Timestamp lastUpdate;
    private String lastUpdatedBy;
    private Timestamp createDate;
    private String createdBy;
    private String password;
    private boolean active;
    private int userId;
    private String userName;
    
    public User(){
    }
    
    public User(int userId, String userName, String password, boolean active, Timestamp createDate, String createdBy, Timestamp lastUpdate, String lastUpdatedBy){
        this.userId = userId;
        this.userName = userName;
        this.password = password;
        this.active = active;
        this.createDate = createDate;
        this.createdBy = createdBy;
        this.lastUpdate = lastUpdate;
        this.lastUpdatedBy = lastUpdatedBy;
    }
    
   public User pullUser(ResultSet rs) throws SQLException{
        User thisUser = new User();
        
        thisUser.setUserId(rs.getInt("userId"));
        thisUser.setUserName(rs.getString("userName"));
        thisUser.setPassword(rs.getString("password"));
        thisUser.setActive(rs.getBoolean("active"));
        thisUser.setCreateDate(rs.getTimestamp("createDate"));
        thisUser.setCreatedBy(rs.getString("createdBy"));
        thisUser.setLastUpdate(rs.getTimestamp("lastUpdate"));
        thisUser.setLastUpdatedBy("lastUpdatedBy");
        
        return thisUser;
    }
    
    public void setUserName(String userName){
        this.userName = userName;
    }
    
    public String getUserName(){
        return this.userName;
    }
    
     public void setUserId(int userId){
        this.userId = userId;
    }
    
    public int getUserId(){
        return this.userId;
    }
    
    
    public void setActive(boolean active){
        this.active = active;
    }
    
    public boolean getActive(){
        return this.active;
    }
    public void setPassword(String password){
        this.password = password;
    }
    
    public String getPassword(){
        return this.password;
    }
    
     public void setCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }
    
    public String getCreatedBy(){
        return this.createdBy;
    }
    public void setCreateDate(Timestamp createDate){
        this.createDate = createDate;
    }
    
    public Timestamp getCreateDate(){
        return this.createDate;
    }
    
   public void setLastUpdatedBy(String lastUpdatedBy){
        this.lastUpdatedBy = lastUpdatedBy;
    }
    
    public String getLastUpdatedBy(){
        return this.lastUpdatedBy;
    }
    
    public void setLastUpdate(Timestamp lastUpdate){
        this.lastUpdate = lastUpdate;
    }
    
    public Timestamp getLastUpdate(){
        return this.lastUpdate;
    }
    
    
    
    
    
    @Override
    public String toString(){
        return this.getUserName();
    }
}
 