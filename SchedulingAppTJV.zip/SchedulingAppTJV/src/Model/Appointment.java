/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Timestamp;
import java.sql.SQLException;
import java.sql.ResultSet;

public class Appointment {
    private int appointmentId;
    private int customerId;
    private int userId;
    private String title;
    private String description;
    private String location;
    private String contact;
    private String type;
    private String url;
    private Timestamp start;
    private Timestamp end;
    private Timestamp createDate;
    private String createdBy;
    private Timestamp lastUpdate;
    private String lastUpdateBy;
    
    public Appointment(){
        
    }
    
    public void setAppointmentId(int appointmentId){
        this.appointmentId = appointmentId;
    }
    
    public int getAppointmentId(){
        return this.appointmentId;
    }
    
    public Appointment apptData(ResultSet rs) throws SQLException{
        Appointment a = new Appointment();
        
        a.setAppointmentId(rs.getInt("appointmentId"));
        a.setCustomerId(rs.getInt("customerId"));
        a.setUserId(rs.getInt("userId"));
        a.setTitle(rs.getString("title"));
        a.setDescription(rs.getString("description"));
        a.setLocation(rs.getString("location"));
        a.setContact(rs.getString("contact"));
        a.setType(rs.getString("type"));
        a.setUrl(rs.getString("url"));
        a.setStart(DBconn.convertFromUTC(rs.getTimestamp("start")));
        a.setEnd(DBconn.convertFromUTC(rs.getTimestamp("end")));
        a.setCreateDate(rs.getTimestamp("createDate"));
        a.setCreatedBy(rs.getString("createdBy"));
        a.setLastUpdate(rs.getTimestamp("lastUpdate"));
        a.setLastUpdateBy(rs.getString("lastUpdatedBy"));
        
        return a;
    }
    
   
    
    public void setUserId(int userId){
        this.userId = userId;
    }
    
    public int getUserId(){
        return this.userId;
    }
    
    public void setTitle(String title){
        this.title = title;
    }
    
    public String getTitle(){
        return this.title;
    }
    
    public void setDescription(String description){
        this.description = description;
    }
    
    public String getDescription(){
        return this.description;
    }
    
    public void setLocation(String location){
        this.location = location;
    }
    
    public String getLocation(){
        return this.location;
    }
    
    public void setContact(String contact){
        this.contact = contact;
    }
    
    public String getContact(){
        return this.contact;
    }
    
    public void setType(String type){
        this.type = type;
    }
    
    public String getType(){
        return this.type;
    }
    
    public void setUrl(String url){
        this.url = url;
    }
    
    public String getUrl(){
        return this.url;
    }
    
    public void setStart(Timestamp start){
        this.start = start;
    }
    
    public Timestamp getStart(){
        return this.start;
    }
    
    public void setEnd(Timestamp end){
        this.end = end;
    }
    
    public Timestamp getEnd(){
        return this.end;
    }
    
     public void setLastUpdate(Timestamp lastUpdate){
        this.lastUpdate = lastUpdate;
    }
    
    public Timestamp getLastUpdate(){
        return this.lastUpdate;
    }
    
    public void setCreateDate(Timestamp createDate){
        this.createDate = createDate;
    }
    
    public Timestamp getCreateDate(){
        return this.createDate;
    }
    
    
    public void setLastUpdateBy(String lastUpdatedBy){
        this.lastUpdateBy = lastUpdatedBy;
    }
    
     public void setCreatedBy(String createdBy){
        this.createdBy = createdBy;
    }
    
    public String getCreatedBy(){
        return this.createdBy;
    }
    
    public String getLastUpdateBy(){
        return this.lastUpdateBy;
    }
    
    
     public void setCustomerId(int customerId){
        this.customerId = customerId;
    }
    
    public int getCustomerId(){
        return this.customerId;
    }
}