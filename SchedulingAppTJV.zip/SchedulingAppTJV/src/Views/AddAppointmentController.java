/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;


import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import Model.Appointment;
import Model.Customer;
import Model.DBconn;
import Model.TimeMethods;
import Model.User;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class AddAppointmentController implements Initializable {
    
    final private User thisUser;
    private Appointment a;
    private ArrayList<Customer> listc;
    private ArrayList<Appointment> currentAppt;
    
    public AddAppointmentController(User thisUser){
        this.thisUser = thisUser;
        this.a = new Appointment();
        this.listc = new ArrayList();
    }
    
    @FXML   private Spinner<String> startTime;

    @FXML   private Spinner<String> endTime;    

    @FXML   private Spinner<String> apstart;

    @FXML   private Spinner<String> apend;


    @FXML   private TextField location;
    
    @FXML   private Button save;

    @FXML   private DatePicker endPicker;
    
    @FXML
    private ChoiceBox<Time> startTimeChooser;

    @FXML
    private ChoiceBox<Time> endTimeChooser;
    
    @FXML   private Button cancel;

    @FXML   private DatePicker startPicker;

    @FXML   private TextField contact;

    @FXML   private TextField url;
    
    
    @FXML   private TextField title;

    @FXML   private TextField description;    
    
    @FXML   private ChoiceBox<String> type;
    
    @FXML   private ChoiceBox<String> custBox;    
    
     // true/false time overlap between other appointments in the existing appointments. 
    private boolean overlapAppt(){
        // User's selections
        Timestamp userTime = TimeMethods.getTimestamp(this.startPicker.getValue(), this.startTime.getValue(), this.apstart.getValue());
        Timestamp enduserTime = TimeMethods.getTimestamp(this.endPicker.getValue(), this.endTime.getValue(), this.apend.getValue());
        // Compare to existing appointments
        for (int i = 0; i < this.currentAppt.size(); i++){
            // After start time AND before end time
            if ((userTime.after(this.currentAppt.get(i).getStart()) && (userTime.before(this.currentAppt.get(i).getEnd()))))
                return true;
            if ((userTime.equals(this.currentAppt.get(i).getStart()) && (enduserTime.after(this.currentAppt.get(i).getEnd()))))
                return true;
            if ((userTime.equals(this.currentAppt.get(i).getStart()) && (enduserTime.equals(this.currentAppt.get(i).getEnd()))))
                return true;
            if ((enduserTime.after(this.currentAppt.get(i).getStart()) && (enduserTime.before(this.currentAppt.get(i).getEnd()))))
                return true;
            if (enduserTime.after(this.currentAppt.get(i).getStart()) && (enduserTime.equals(this.currentAppt.get(i).getEnd()))){
                return true;
            } else {
            }
        }
        return false;
    }
    
    // puts the type list within type box
    private void typeOptions(){
        ObservableList<String> options = FXCollections.observableArrayList();
        options.add("Coffee Meeting");
        options.add("Brunch Meeting");
        options.add("Onsite Conference");
        options.add("Tele-Conference");
        
        this.type.setItems(options);
    }
    
     // puts custlist into customer choice box
    private void custBoxOptions(){
        ObservableList<String> custs = FXCollections.observableArrayList();
        
        for (int i = 0; i < listc.size(); i++){
            custs.add(listc.get(i).getCustomerName());
        }
        
        custBox.setItems(custs);
    }
       

    @FXML
    void doCancel(ActionEvent event) throws IOException {
        // Close this window
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
        
        // Load Appointments Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/Appointments.fxml"));
        Views.AppointmentsCenterController controller = new Views.AppointmentsCenterController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    
   
    
    /*
     *  Uses methods to make new appointment
     */
    private boolean makeAppointment(){
        Timestamp moment = new Timestamp(System.currentTimeMillis());
        
        a.setTitle(title.getText());
        a.setDescription(description.getText());
        a.setContact(contact.getText());
        a.setUrl(url.getText());
        a.setLocation(location.getText());
        a.setCreateDate(moment);
        a.setCreatedBy(thisUser.getUserName());
        a.setLastUpdate(moment);
        a.setLastUpdateBy(thisUser.getUserName());
        a.setType(type.getValue());
        a.setUserId(thisUser.getUserId());
        
        // Set Customer ID of selected customer
        for (int i = 0; i < listc.size(); i++){
            if (!listc.get(i).getCustomerName().equals(this.custBox.getValue())){
            } else {
                int custId = listc.get(i).getCustomerId();
                a.setCustomerId(custId);
            }
        }
        
        // Get date "YYYY-MM-DD"
        LocalDate startDate = startPicker.getValue();
        LocalDate endDate = endPicker.getValue();
        
        // Get time
        String startString = this.startTime.getValue();
        String endString = this.endTime.getValue();
        String apStart = this.apstart.getValue();
        String apEnd = this.apend.getValue();
        
        // Create a timestamp and set the Start and End values of Appointment
        Timestamp startStamp = TimeMethods.getTimestamp(startDate, startString, apStart);   
        Timestamp endStamp = TimeMethods.getTimestamp(endDate, endString, apEnd);
        
        // Overlap check
        if(this.overlapAppt()) {
            return false;
        } else if (TimeMethods.hourToken(startStamp) < 7 || TimeMethods.hourToken(endStamp) > 18){
            return false;
        }
        else{
            a.setStart(startStamp);
            a.setEnd(endStamp);
            return true;
        }
    }
    
    /*
     *  Add the new appt to database
     */
    private void insertToDB(){
        String iQ = "INSERT INTO U06ZEq.appointment (customerId, title, description, location, contact, url, start, end, createDate, createdBy, lastUpdate, lastUpdateBy, userId, type)"
        + "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
        
        try{
            PreparedStatement insert = DBconn.getConn().prepareStatement(iQ);
            insert.setInt(1, a.getCustomerId());
            insert.setString(2, a.getTitle());
            insert.setString(3, a.getDescription());
            insert.setString(4, a.getLocation());
            insert.setString(5, a.getContact());
            insert.setString(6, a.getUrl());
            insert.setTimestamp(7, DBconn.convertToUTC(a.getStart()));
            insert.setTimestamp(8, DBconn.convertToUTC(a.getEnd()));
            insert.setTimestamp(9, a.getCreateDate());
            insert.setString(10, a.getCreatedBy());
            insert.setTimestamp(11, a.getLastUpdate());
            insert.setString(12, a.getLastUpdateBy());
            insert.setInt(13, a.getUserId());
            insert.setString(14, a.getType());
            
            insert.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    
    @FXML
    void doSave(ActionEvent event) throws IOException {
        if (!makeAppointment()){
            Alert alertappt = new Alert(Alert.AlertType.ERROR);
            alertappt.setTitle("Invalid Appointment");
            alertappt.setContentText("Please Select A Valid Appointment Time");
            alertappt.showAndWait();
        }
        else{
            insertToDB();
            
            // Close this window
            Stage stage = (Stage) save.getScene().getWindow();
            stage.close();
        
            // Load Appointments Window after the save
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AppointmentsCenter.fxml"));
            Views.AppointmentsCenterController controller = new Views.AppointmentsCenterController(thisUser);
            loader.setController(controller);

            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage primaryStage = new Stage();
            primaryStage.setScene(scene);
            primaryStage.show();
        }
        
        
        
    }
    
    private void makeTime(){
        ObservableList<String> apPicker = FXCollections.observableArrayList("am", "pm");
        ObservableList<String> timeOptions = FXCollections.observableArrayList(
                "8:00", "9:00", "10:00", "11:00", "12:00", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00"
                );
        
        String beg = "1970-01-01 00:00:00";
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        LocalDateTime dateTime = LocalDateTime.parse(beg, formatter);
        Timestamp moment = Timestamp.valueOf(dateTime);

        SpinnerValueFactory<String> start = new SpinnerValueFactory.ListSpinnerValueFactory<>(timeOptions);
        SpinnerValueFactory<String> end = new SpinnerValueFactory.ListSpinnerValueFactory<>(timeOptions);
        SpinnerValueFactory<String> ampmstart = new SpinnerValueFactory.ListSpinnerValueFactory<>(apPicker);
        SpinnerValueFactory<String> ampmend = new SpinnerValueFactory.ListSpinnerValueFactory<>(apPicker);
      
       // Default value
       start.setValue("9:00");
       end.setValue("9:00");
       ampmstart.setValue("am");
       ampmend.setValue("am");
 
       startTime.setValueFactory(start);
       endTime.setValueFactory(end);
       this.apstart.setValueFactory(ampmstart);
       this.apend.setValueFactory(ampmend);
    }
    
    

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.currentAppt = DBconn.getAppointments("SELECT * FROM U06ZEq.appointment");
        makeTime();
//        getCustomerData();
        this.listc = DBconn.getCustomers("SELECT * FROM U06ZEq.customer");
        custBoxOptions();
        typeOptions();
    }    
    
}
