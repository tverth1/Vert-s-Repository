/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;


import javafx.event.ActionEvent;
import java.net.URL;
import java.util.ArrayList;
import javafx.scene.control.Label;
import javafx.stage.Stage;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;


 
public class TypeByMonthController implements Initializable {
     private String monthselect = "";
     private ArrayList<Integer> meetingrep;
   
    
    @FXML
    private Label coffee;

    @FXML
    private Label brunch;

     @FXML
    private Button close;
     
    @FXML
    private Label onsite;

    @FXML
    private Label tele;
    
    @FXML
    private Label month;
    
   
    
   
    
    public TypeByMonthController(String monthselect, ArrayList<Integer> meetingrep){
        this.meetingrep = meetingrep;
        this.monthselect = monthselect;
    }

    
    void getMeetings(){
        this.month.setText(monthselect);
        
        
       
        coffee.setText(meetingrep.get(3).toString());
        brunch.setText(meetingrep.get(2).toString());
        onsite.setText(meetingrep.get(1).toString());
        tele.setText(meetingrep.get(0).toString());
        
        
       
    }

    @FXML
    void doClose (ActionEvent event) { 
        // Close this window
        Stage stage = (Stage) close.getScene().getWindow();
        stage.close();
    }
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        getMeetings();
    }    
    
}
