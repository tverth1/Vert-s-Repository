/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import Model.User;
import java.io.IOException;
import java.net.URL;
import Model.Customer;
import Model.DBconn;
import static com.mysql.jdbc.Messages.getString;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;



public class AddCustomerController implements Initializable {
    
    private Customer c;
    final private User thisUser;
    
    @FXML  private TextField name;

    @FXML  private TextField address;
    
    @FXML  private Button save;

    @FXML  private TextField addressTWO;
    
    @FXML  private TextField city;

    @FXML  private TextField zip;
   
    @FXML  private Button cancel;
    
    @FXML  private TextField country;

    @FXML  private TextField phone;

    
    
    public AddCustomerController(User thisUser){
        this.thisUser = thisUser;
    }
/*
     *  Create a new customer based on the user's inputs
     *  Update "createdBy" and "lastUpdatedBy" fields to current user
     */
    private void createCustomer()
         throws SQLException {
        //validate form completion
        if(name.getText().isEmpty()
        || address.getText().isEmpty() //address 2 is optional. Can be empty
        || city.getText().isEmpty() 
        || country.getText().isEmpty() 
        || zip.getText().isEmpty() 
        || phone.getText().isEmpty()) {
            Alert subalert = new Alert(Alert.AlertType.ERROR);
            subalert.setTitle(getString("Error"));
            subalert.setContentText(getString("Can't have empty values"));
            subalert.showAndWait();
        }
        else {
        Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        c = new Customer();
        c.setCustomerName(name.getText());
        c.setPhone(phone.getText());
        c.setAddress(address.getText());
        c.setAddress2(addressTWO.getText());
        c.setCity(city.getText());
        c.setCountry(country.getText());
        c.setPostalCode(zip.getText());
        c.setCreatedBy(thisUser.getUserName());
        c.setCreateDate(timestamp);
        c.setLastUpdateBy(thisUser.getUserName());
        c.setLastUpdate(timestamp);
    }
    } 
    
    /*
     *  Close window without saving any changes
     */
    @FXML
    void doCancel(ActionEvent event) throws IOException {
        // Close the window
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
        
        // Load Customer Rcords Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/CustomerRecords.fxml"));
        Views.CustomerFilesController controller = new Views.CustomerFilesController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    @FXML
    void doSave(ActionEvent event) throws IOException, SQLException {
        createCustomer();
        addCountryToDB();
        giveCountryId();
        insertCityDB();
        giveCityId();
        insertAddressDB();
        giveAddId();
        insertCustomerDB();
        updateCustomerId();
        
        // Close the window
        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
        
        // Open Customer Records Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/CustomerRecords.fxml"));
        Views.CustomerFilesController controller = new Views.CustomerFilesController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    
    /*
     *  Add new customer data to Country Table in DB
     */
    private void addCountryToDB(){
        String insertQuery = "INSERT INTO U06ZEq.country (country, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?)";
        String checkQuery = "SELECT * FROM U06ZEq.country WHERE country=?";
        PreparedStatement psInsert = null;
        
        try{
            psInsert = DBconn.getConn().prepareStatement(insertQuery);
            psInsert.setString(1, c.getCountry());
            psInsert.setTimestamp(2, c.getCreateDate());
            psInsert.setString(3, c.getCreatedBy());
            psInsert.setTimestamp(4, c.getLastUpdate());
            psInsert.setString(5, c.getLastUpdateBy());
            
            // Check if Country DB already contains the country
            PreparedStatement psq = DBconn.getConn().prepareStatement(checkQuery);
            psq.setString(1, c.getCountry());
            ResultSet results = psq.executeQuery();           
            
            if (results.next()) {
            } else {
                psInsert.execute();
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  get new country Id
     */
    private void giveCountryId(){
        try{
            PreparedStatement ps = DBconn.getConn().prepareStatement("SELECT * FROM U06ZEq.country WHERE country=?");
            ps.setString(1, c.getCountry());
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()){
            } else {
                c.setCountryId(rs.getInt("countryId"));
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  Add new customer data to City Table in DB
     */
    private void insertCityDB(){
        String insertQuery = "INSERT INTO U06ZEq.city (city, countryId, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?,?)";
        String checkQuery = "SELECT * FROM U06ZEq.city WHERE city=?";
        PreparedStatement psInsert = null;
        
        try{
            psInsert = DBconn.getConn().prepareStatement(insertQuery);
            psInsert.setString(1, c.getCity());
            psInsert.setInt(2, c.getCountryId());
            psInsert.setTimestamp(3, c.getCreateDate());
            psInsert.setString(4, c.getCreatedBy());
            psInsert.setTimestamp(5, c.getLastUpdate());
            psInsert.setString(6, c.getLastUpdateBy());
            
            // Check if Country DB already contains the country
            PreparedStatement psCheck = DBconn.getConn().prepareStatement(checkQuery);
            psCheck.setString(1, c.getCity());
            ResultSet results = psCheck.executeQuery();           
            
            if (results.next()) {
            } else {
                psInsert.execute();
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  Update cityId for new customer
     */
    private void giveCityId(){
        try{
            PreparedStatement ps = DBconn.getConn().prepareStatement("SELECT * FROM U06ZEq.city WHERE city=?");
            ps.setString(1, c.getCity());
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()){
            } else {
                c.setCityId(rs.getInt("cityId"));
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  Add new customer data to Address Table in DB
     */
    private void insertAddressDB(){
        String add = "INSERT INTO U06ZEq.address (address, address2, cityId, postalCode, phone, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?,?,?,?,?)";
        String Query = "SELECT * FROM U06ZEq.address WHERE address=?";
        PreparedStatement addInsert = null;
        
        try{
            addInsert = DBconn.getConn().prepareStatement(add);
            addInsert.setString(1, c.getAddress());
            addInsert.setString(2, c.getAddress2());
            addInsert.setInt(3, c.getCityId());
            addInsert.setString(4, c.getPostalCode());
            addInsert.setString(5, c.getPhone());
            addInsert.setTimestamp(6, c.getCreateDate());
            addInsert.setString(7, c.getCreatedBy());
            addInsert.setTimestamp(8, c.getLastUpdate());
            addInsert.setString(9, c.getLastUpdateBy());
            
            // Check if Country DB already contains the country
            PreparedStatement listener = DBconn.getConn().prepareStatement(Query);
            listener.setString(1, c.getAddress());
            ResultSet results = listener.executeQuery();           
            
            if (results.next()) {
            } else {
                addInsert.execute();
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  Update addressId for new customer
     */
    private void giveAddId(){
        try{
            PreparedStatement ps = DBconn.getConn().prepareStatement("SELECT * FROM U06ZEq.address WHERE address=?");
            ps.setString(1, c.getAddress());
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()){
            } else {
                c.setAddressId(rs.getInt("addressId"));
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  Add new customer data to Customer Table in DB
     *  Update customerId for new customer
     */
    private void insertCustomerDB(){
        String cust = "INSERT INTO U06ZEq.customer (customerName, addressId, active, createDate, createdBy, lastUpdate, lastUpdateBy) VALUES(?,?,?,?,?,?,?)";
        String Query = "SELECT * FROM U06ZEq.customer WHERE customerName=? AND addressId=?";
        PreparedStatement cusInsert = null;
        
        try{
            cusInsert = DBconn.getConn().prepareStatement(cust);
            cusInsert.setString(1, c.getCustomerName());
            cusInsert.setInt(2, c.getAddressId());
            cusInsert.setBoolean(3, c.getActive());
            cusInsert.setTimestamp(4, c.getCreateDate());
            cusInsert.setString(5, c.getCreatedBy());
            cusInsert.setTimestamp(6, c.getLastUpdate());
            cusInsert.setString(7, c.getLastUpdateBy());
            
            // Check if Country DB already contains the country
            PreparedStatement psCheck = DBconn.getConn().prepareStatement(Query);
            psCheck.setString(1, c.getCustomerName());
            psCheck.setInt(2, c.getAddressId());
            ResultSet results = psCheck.executeQuery();           
            
            if (results.next()) {
            } else {
                cusInsert.execute();
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    /*
     *  Update customerId for new customer
     */
    private void updateCustomerId(){
        try{
            PreparedStatement ps = DBconn.getConn().prepareStatement("SELECT * FROM U06ZEq.customer WHERE customerName=? AND addressId=? AND createDate=?");
            ps.setString(1, c.getCustomerName());
            ps.setInt(2, c.getAddressId());
            ps.setTimestamp(3, c.getCreateDate());
            ResultSet rs = ps.executeQuery();
            
            if (!rs.next()){
            } else {
                c.setCustomerId(rs.getInt("customerId"));
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }


    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
