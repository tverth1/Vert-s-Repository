/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;



import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Locale;
import java.util.ResourceBundle;
import java.sql.Timestamp;
import java.time.LocalTime;
import java.util.TimeZone;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import Model.TimeMethods;
import Model.User;
import javafx.stage.Stage;
import Model.Appointment;
import Model.Customer;
import Model.DBconn;



public class AppointmentsCenterController implements Initializable {
    
    final private User thisUser;
    private Appointment selectAppt;
    private ObservableList<Appointment> lista;
    private ObservableList<Appointment> mList;
    private ObservableList<Appointment> wList;
    private ArrayList<Appointment> aMetaList;
    private ArrayList<Appointment> monthDataList;
    private ArrayList<Appointment> weekDataList;
    private ArrayList<Appointment> userAList;
    private ArrayList<Customer> listc;
    final private Locale loc;
    private Timestamp loginTime;
    private boolean login;
    private ZoneId zoneid;
    
    
    @FXML  private TableView<Appointment> appTV;
     
    @FXML  private TableColumn<Appointment, String> titC;

    @FXML  private TableColumn<Appointment, String> descripC;

    @FXML  private TableColumn<Appointment, String> locC;

    @FXML  private TableColumn<Appointment, String> contC;

    @FXML  private TableColumn<Appointment, String> urlC;

    @FXML  private TableColumn<Appointment, Timestamp> startC;

    @FXML  private TableColumn<Appointment, Timestamp> endC;

    
    @FXML  private RadioButton month;

    @FXML  private RadioButton week;
    
    @FXML  private RadioButton all;
    
    @FXML  private Button add;

    @FXML  private Button update;
    
    @FXML  private Button delete;   
    
    @FXML  private Button reports;    

    @FXML  private Button records;
    
    @FXML  private Button logoff;    
    
    @FXML  private Button customer;
    
   
     public AppointmentsCenterController(User thisUser){
        this.thisUser = thisUser;
        loc = Locale.getDefault();
    }  
    
    public AppointmentsCenterController(User thisUser, Timestamp loginTime, boolean login){
        this.thisUser = thisUser;
        loc = Locale.getDefault();
        zoneid = ZoneId.systemDefault();
        this.loginTime = loginTime;
        this.login = login;
        this.userAList = new ArrayList();
        this.listc = new ArrayList();
    } 
    
   
    
    @FXML
    void doLogOff(ActionEvent event) throws IOException {
        //Close 
        DBconn.closeConn();
        
        // Close 
        Stage stage = (Stage) logoff.getScene().getWindow();
        stage.close();
        
        // Open
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/LoginScreen.fxml"));
        Views.LoginScreenController controller = new Views.LoginScreenController();
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    
    /*
     *  Opens the Customer's Record (Modify Customer screen with selected customer)
     */
    @FXML
    void doRecords(ActionEvent event) throws IOException {        
        // Load Appointments Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/CustomerFiles.fxml"));
        Views.CustomerFilesController controller = new Views.CustomerFilesController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
   
    @FXML
    void doReports(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AppReports.fxml"));
        Views.AppReportsController controller = new Views.AppReportsController(thisUser);
        loader.setController(controller);

        // Open Reports Window
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    

    @FXML
    void doDelete(ActionEvent event) {
        try{
            // appsel represents variable for deleting appointment from database
            Appointment appsel = this.appTV.getSelectionModel().getSelectedItem(); 
            String deleteQuery = "DELETE FROM U06ZEq.appointment WHERE appointmentId=?";
            PreparedStatement deleteStmt = DBconn.getConn().prepareStatement(deleteQuery);
            deleteStmt.setInt(1, appsel.getAppointmentId());
            deleteStmt.execute();
            
            // This updates to the new list on the tableview
            for (int i = 0; i < lista.size(); i++){
                if (lista.get(i).getAppointmentId() != appsel.getAppointmentId()){
                } else {
                    lista.remove(lista.get(i));
                }
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    
    @FXML
    void doAddAppt(ActionEvent event) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AddAppointment.fxml"));
        Views.AddAppointmentController controller = new Views.AddAppointmentController(thisUser);
        loader.setController(controller);

        // Open Add Appointment Window
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
        
        // Close this window
        Stage stage = (Stage) add.getScene().getWindow();
        stage.close();
    }
    
    
    @FXML
    void doUpdate(ActionEvent event) throws IOException { 
        try{
            selectAppt = appTV.getSelectionModel().getSelectedItem();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/ModifyAppointment.fxml"));
            Views.ModifyAppointmentController controller = new Views.ModifyAppointmentController(thisUser, selectAppt.getAppointmentId());
            loader.setController(controller);

            // Open Update Appointment window
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage primaryStage = new Stage();
            primaryStage.setScene(scene);
            primaryStage.show();
            
            // Close this window
            Stage stage = (Stage) update.getScene().getWindow();
            stage.close();
        }
        catch(IOException e){
            Alert upalert = new Alert(Alert.AlertType.ERROR);
            upalert.setTitle("Select Appointment");
            upalert.setContentText("Must select an appointment to update.");
            upalert.showAndWait();
        }
    }
    
    /*
     *  Fill in the Appointment Table
     */
    private void showAppTV(){
        titC.setCellValueFactory(new PropertyValueFactory("title"));
        descripC.setCellValueFactory(new PropertyValueFactory("description"));
        locC.setCellValueFactory(new PropertyValueFactory("location"));
        contC.setCellValueFactory(new PropertyValueFactory("contact"));
        urlC.setCellValueFactory(new PropertyValueFactory("url"));
        startC.setCellValueFactory(new PropertyValueFactory("start"));
        endC.setCellValueFactory(new PropertyValueFactory("end"));
        
        appTV.setItems(lista);
        appTV.refresh();
    }    
    /*private void zonedTime(){
        // apptDataList is in the timezone from the Database
       // ZonedDateTime zdt = ZonedDateTime.now().toOffsetDateTime().atZoneSameInstant(this.zoneid);
        //Timestamp zonedTS = Timestamp.valueOf(zdt.toLocalDateTime());
        
         // each appt converted to said user's tz
         aMetaList.forEach((appt) -> {
             // Start Time
             ZonedDateTime zonedstart = appt.getStart().toLocalDateTime().atZone(ZoneId.of("UTC"));
             ZonedDateTime startSd = zonedstart.withZoneSameInstant(ZoneId.systemDefault());
             Timestamp start = Timestamp.valueOf(startSd.toLocalDateTime());
             
             // End Time
             ZonedDateTime zonedend = appt.getEnd().toLocalDateTime().atZone(ZoneId.of("UTC"));
             ZonedDateTime endSd = zonedend.withZoneSameInstant(ZoneId.systemDefault());
             Timestamp end = Timestamp.valueOf(endSd.toLocalDateTime());

             // display times relevant to user location
             appt.setStart(start);
             appt.setEnd(end);
         });
    }*/

    @FXML
    void doAllRadio(ActionEvent event) {
        // Make sure the ArrayList is empty before pulling data
        this.aMetaList.clear();
        this.lista.clear();
        
        this.aMetaList = DBconn.getAppointments("SELECT * FROM U06ZEq.appointment");
        this.lista = FXCollections.observableArrayList(aMetaList);
        showAppTV();
    }
    
     @FXML
    void doWeekRadio(ActionEvent event) {
        ObservableList<Appointment> weekList = FXCollections.observableArrayList();
        Timestamp temp = new Timestamp(System.currentTimeMillis());
        int thisMonth = TimeMethods.monthToken(temp);
        int thisWeek = TimeMethods.weekToken(temp);
        int startMonth;
        int startWeek;
        //lambda for filtering appts not in current week
        lista.forEach((appt)->{if(TimeMethods.weekToken(appt.getStart())==thisWeek){weekList.add(appt);}});
        
        // Update Table View to weekly appointments
        this.appTV.setItems(weekList);
        this.appTV.refresh();
    }
    @FXML
    void doMonthRadio(ActionEvent event) {
        ObservableList<Appointment> monthList = FXCollections.observableArrayList();
        Timestamp tempTimestamp = new Timestamp(System.currentTimeMillis());
        int thisMonth = TimeMethods.monthToken(tempTimestamp);
        int startMonth = -1;
      
        // Lambda
        //  - filter appointments not in current month
        lista.forEach((appt)->{if(TimeMethods.monthToken(appt.getStart()) != thisMonth){} else {
            monthList.add(appt);
        }});
                    
        // Update Table View  to monthly appointments
        this.appTV.setItems(monthList);
        this.appTV.refresh();
    }
    
   
            
    /*
     *  Checks if there are any appointments within 15 minutes of user's login
     */
    private void closestAppt(){
        int m = TimeMethods.monthToken(loginTime);
        int w = TimeMethods.weekToken(loginTime);
        int d = TimeMethods.dayToken(loginTime);
        LocalTime sol = TimeMethods.timeToken(loginTime);
        int hr = sol.getHour();
        int min = sol.getMinute();
             
        for (int i = 0; i < this.aMetaList.size(); i++){
            int startM = TimeMethods.monthToken(aMetaList.get(i).getStart());
            int startW = TimeMethods.weekToken(aMetaList.get(i).getStart());
            int startD = TimeMethods.dayToken(aMetaList.get(i).getStart());
            LocalTime start = TimeMethods.timeToken(aMetaList.get(i).getStart());
            int startHr = start.getHour();
            int startMin = start.getMinute();
            
            if (((aMetaList.get(i).getUserId() != this.thisUser.getUserId() || m != startM) || w != startW) || d != startD){
            } else {
                if ((hr != startHr || startMin < min) || startMin > (min + 15))if (((hr + 1) != startHr || startMin > (min-45)) || startMin < 0){ // none inside 15 mins
                    
                }
                else{ // start time is next hour but within 15 minutes
                    Alert closest = new Alert(Alert.AlertType.INFORMATION);
                    closest.setTitle("Appointment Near!");
                    closest.setContentText("Appointment in 15 minutes!");
                    closest.showAndWait();
                }
                else {
                    // same hour within 15 minutes
                    Alert closest = new Alert(Alert.AlertType.INFORMATION);
                    closest.setTitle("Appointment Near!");
                    closest.setContentText("Appointment in 15 minutes!");
                    closest.showAndWait();
                }
            }
        }
    }
    
        /*
     *  Pull all customer data from database and put it in a List
     */
    private void getCustList(){
        try{
            // get customer data form cust table
            Statement stmt = DBconn.getConn().createStatement();
            ResultSet custRS = stmt.executeQuery("SELECT customerName, phone, address, city, country, c.customerId, a.addressId, d.cityId, e.countryId FROM U06ZEq.customer c "
                    + "JOIN U06ZEq.address a ON c.addressId=a.addressId "
                    + "JOIN U06ZEq.city d ON a.cityId=d.cityId "
                    + "JOIN U06ZEq.country e ON d.countryId=e.countryId;");
            
            while(custRS.next()){
                Customer cust = new Customer();
                cust.setCustomerName(custRS.getString("customerName"));
                cust.setPhone(custRS.getString("phone"));
                cust.setAddress(custRS.getString("address"));
                cust.setCity(custRS.getString("city"));
                cust.setCountry(custRS.getString("country"));
                cust.setCustomerId(custRS.getInt("customerId"));
                cust.setAddressId(custRS.getInt("addressId"));
                cust.setCityId(custRS.getInt("cityId"));
                cust.setCountryId(custRS.getInt("countryId"));
                this.listc.add(cust);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        aMetaList = new ArrayList();
        this.aMetaList = DBconn.getAppointments("SELECT * FROM U06ZEq.appointment");
       // this.zonedTime();
        
        // Lambda Example: sort the appointments by month for the table view
        aMetaList.sort((Appointment list1, Appointment list2)->TimeMethods.monthToken(list1.getStart())-TimeMethods.monthToken(list2.getStart()));
        
        // Update the ObservableList
        lista = FXCollections.observableList(aMetaList);
        
        this.showAppTV();
        if (!login){
        } else {
            this.closestAppt();
         }
    }    
    
}
