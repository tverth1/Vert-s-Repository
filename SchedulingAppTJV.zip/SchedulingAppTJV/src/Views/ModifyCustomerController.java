/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;


import Model.User;
import java.io.IOException;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import java.net.URL;
import java.sql.Timestamp;
import java.util.ArrayList;
import Model.Customer;
import Model.DBconn;
import static com.mysql.jdbc.Messages.getString;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.Scene;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.control.Alert;
import javafx.stage.Stage;


public class ModifyCustomerController implements Initializable {
    
    final private User thisUser;
    final private Customer custSelect;
    private Customer modifiedCust;
     private ArrayList<Customer> countriesArray;
    private ArrayList<Customer> citiesArray;
    private ArrayList<Customer> addressesArray;
    private ArrayList<Customer> listc;
    
    @FXML  private TextField name;

    @FXML  private TextField address1;

    @FXML  private TextField cityText;
    
    @FXML  private Button save;

    @FXML  private Button cancel;

    @FXML  private TextField zip;

    @FXML  private TextField countryText;

    @FXML  private TextField phone;

    @FXML  private TextField address2;

    private boolean alteredCust;
    private boolean alteredAdd;
    private boolean alteredCity;
    private boolean alteredCountry;
    
   
   
   
    
    public ModifyCustomerController(User thisUser, Customer custSelect){
        this.thisUser = thisUser;
        this.custSelect = custSelect;
        this.alteredCust = false;
        this.alteredAdd = false;
        this.alteredCity = false;
        this.alteredCountry = false;
        this.listc = new ArrayList();
        this.addressesArray = new ArrayList();
        this.modifiedCust = new Customer();
        this.countriesArray = new ArrayList();
        this.citiesArray = new ArrayList();
        
    }
        private void doSetFields(){
        // Set the textfields to the selected customer's data
        name.setText(custSelect.getCustomerName());
        phone.setText(custSelect.getPhone());
        address1.setText(custSelect.getAddress());
        address2.setText(custSelect.getAddress2());
        cityText.setText(custSelect.getCity());
        countryText.setText(custSelect.getCountry());
        zip.setText(custSelect.getPostalCode());
        
        // Set all the lists
        this.countriesArray = DBconn.getCountry();
        this.citiesArray = DBconn.getCity();
        this.addressesArray = DBconn.getAddress();
        
        // Set updated customer data
        this.modifiedCust = this.custSelect;
    }
    /*
     *  Close window without saving changes
     */
    @FXML
    void doCancel(ActionEvent event) throws IOException 
    {
        // Close window
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
        
        // Load Appointments Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/CustomerFiles.fxml"));
        Views.CustomerFilesController controller = new Views.CustomerFilesController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

   
    private void doModifyCustomer(){
        // Country
        if (this.alteredCountry){
            //check DB if new
            this.countriesArray.stream().filter((country) -> (this.countryText.getText().equals(country.getCountry()))).map((country) -> {
                modifiedCust.setCountry(country.getCountry());
                return country;
            }).forEachOrdered((country) -> {
                modifiedCust.setCountryId(country.getCountryId());
            });
            // Else, add country and update CountryId
            this.modifiedCust.setCountry(this.countryText.getText());
            DBconn.insertCountry(modifiedCust);
            
            // Update Country ID
            this.countriesArray = DBconn.getCountry();
            this.countriesArray.stream().filter((country) -> (this.modifiedCust.getCountry().equals(country.getCountry()))).forEachOrdered((country) -> {
                this.modifiedCust.setCountryId(country.getCountryId());
            });
        }
        
        // Update City
        if (this.alteredCity){
            // Check if city exists in DB
            this.citiesArray.stream().filter((city) -> (this.cityText.getText().equals(city.getCity()))).map((city) -> {
                modifiedCust.setCity(city.getCountry());
                return city;
            }).forEachOrdered((city) -> {
                modifiedCust.setCityId(city.getCountryId());
            });
            // Else, add city
            this.modifiedCust.setCity(this.cityText.getText());
            DBconn.insertCity(modifiedCust);
            
            // Update City ID
            this.citiesArray = DBconn.getCity();
            this.citiesArray.stream().filter((city) -> (this.modifiedCust.getCity().equals(city.getCity()))).forEachOrdered((city) -> {
                this.modifiedCust.setCityId(city.getCityId());
            });
        }
        
        // Update Address
        if (this.alteredAdd){
            // Check if address exists in DB
            this.addressesArray.stream().filter((address) -> (this.address1.getText().equals(address.getAddress()))).map((address) -> {
                modifiedCust.setAddress(address.getAddress());
                return address;
            }).forEachOrdered((address) -> {
                modifiedCust.setAddressId(address.getAddressId());
            });
            // Else, add address
            this.modifiedCust.setAddress(this.address1.getText());
            this.modifiedCust.setAddress2(this.address2.getText());
            this.modifiedCust.setPostalCode(this.zip.getText());
            this.modifiedCust.setPhone(this.phone.getText());
            DBconn.insertAddress(modifiedCust);
            
            // Update Address ID 
            this.addressesArray = DBconn.getAddress();
            this.addressesArray.stream().filter((address) -> (this.modifiedCust.getAddress().equals(address.getAddress()))).forEachOrdered((address) -> {
                this.modifiedCust.setAddressId(address.getAddressId());
            });
        }
        
        // Update Customer
        if (this.alteredCust){
            this.modifiedCust.setCustomerName(this.name.getText());
            this.addressesArray.stream().filter((address) -> (this.modifiedCust.getAddress().equals(address.getAddress()))).forEachOrdered((address) -> {
                this.modifiedCust.setAddressId(address.getAddressId());
            });
            
        }
        DBconn.updateCustomer(modifiedCust);
       
    }
    private boolean checkFields()
    throws SQLException {
        //validate form completion
        if(name.getText().isEmpty()
        || address1.getText().isEmpty() //address 2 is optional. Can be empty
        || cityText.getText().isEmpty() 
        || countryText.getText().isEmpty() 
        || zip.getText().isEmpty() 
        || phone.getText().isEmpty()) {
            Alert subalert = new Alert(Alert.AlertType.ERROR);
            subalert.setTitle(getString("Error"));
            subalert.setContentText(getString("Can't have empty values"));
            subalert.showAndWait();
        }
        return false;
    }
     /*
     *  Save all the changes to the Selected Customer's database data and close window
     */
    @FXML
    void doSave(ActionEvent event) throws IOException, SQLException {
        //If there are any changes, update the customer (set LastUpdate, LastUpdateBy first!
        if (!checkFields());
        this.modifiedCust.setLastUpdate(new Timestamp(System.currentTimeMillis()));
        this.modifiedCust.setLastUpdateBy(this.thisUser.getUserName());
        this.doModifyCustomer();
        
        // Close window
        Stage stage = (Stage) save.getScene().getWindow();
        stage.close();
        
        // Load Appointments Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/CustomerFiles.fxml"));
        Views.CustomerFilesController controller = new Views.CustomerFilesController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
    

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) 
    {
        this.doSetFields();
        
        //anyone making a change to these spots typically accompanied by an address 
        //change & needs to re-enter the other values to ensure accuracy.
        this.address1.setOnMouseClicked(e -> { 
            this.address1.clear();
            this.address2.clear();
            this.cityText.clear();
            this.countryText.clear();
            this.zip.clear();
            this.phone.clear();
        });
     

        this.name.textProperty().addListener((observable, oldValue, newValue)->{
            this.alteredCust = true;
        });
        
        this.address1.textProperty().addListener((obs, oldVal, newVal)->{
            this.alteredAdd = true;
        });
        
        this.countryText.textProperty().addListener((obs, oldVal, newVal)->{
            this.alteredCountry = true;
        });
        
        this.cityText.textProperty().addListener((obs, oldVal, newVal)->{
            this.alteredCity = true;
        });
    }
}