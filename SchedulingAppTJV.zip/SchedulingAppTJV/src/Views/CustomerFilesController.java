/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;


import Model.User;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import Model.Customer;
import Model.DBconn;
import java.util.Iterator;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;


/**
 * FXML Controller class
 *
 * @author TJV
 */
public class CustomerFilesController implements Initializable {
    
    private ObservableList<Customer> listc;
    private List<Customer> cusData;
    final private User thisUser;
    
    @FXML   private Button save;

    @FXML   private Button cancel;

    @FXML   private TableView<Customer> cusTV;

    @FXML   private TableColumn<Customer, String> nameC;

    @FXML   private TableColumn<Customer, Integer> phoneC;

    @FXML   private TableColumn<Customer, Integer> addC;

    @FXML   private TableColumn<Customer, String> cityC;

    @FXML   private TableColumn<Customer, String> countryC;
    
    @FXML   private Button add;

    @FXML   private Button update;

    @FXML   private Button delete;

    
    /*
     *  Close the window without saving any changes
     */
    @FXML
    void doCancel(ActionEvent event) throws IOException {
        // Closes screen
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
    }

    /*
     *  Constructor: user param for logged in user
     *  @param 
     */
    public CustomerFilesController(User thisUser){
        this.thisUser = thisUser;
    }
     /*
     *  starts "ModifyCustomer" window
     */
    @FXML
    void doUpdate(ActionEvent event) throws IOException {
        try{
            Customer cuselect = this.cusTV.getSelectionModel().getSelectedItem();
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/ModifyCustomer.fxml"));
            Views.ModifyCustomerController controller = new Views.ModifyCustomerController(thisUser, cuselect);
            loader.setController(controller);

            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage primaryStage = new Stage();
            primaryStage.setScene(scene);
            primaryStage.show();
            
            // Close window
            Stage stage = (Stage) update.getScene().getWindow();
            stage.close();
        }
        catch(IOException e){ // Customer is not selected before Update button clicked
            e.printStackTrace();
            Alert upalert = new Alert(Alert.AlertType.ERROR);
            upalert.setTitle("Customer Files Update");
            upalert.setContentText("To update, Customer Must Be Selected.");
            upalert.showAndWait();
        }
    }

    /*
     *  Pull all Customer data from Country, City, Address, and Customer Databases
     */
    private void getCustInfo(){
        ArrayList<Customer> countryList = DBconn.getCountry();
        ArrayList<Customer> cityList = DBconn.getCity();
        ArrayList<Customer> addList = DBconn.getAddress();
        ArrayList<Customer> allCust = DBconn.getCustomers("SELECT * FROM U06ZEq.customer");
        
        for (Customer c : allCust) {
            // Add address/city/country ID to custs
            addList.stream().filter((address) -> (c.getAddressId() == address.getAddressId())).map((address) -> {
                c.setAddress(address.getAddress());
                return address;
            }).map((address) -> {
                c.setAddress2(address.getAddress2());
                return address;
            }).map((address) -> {
                c.setPostalCode(address.getPostalCode());
                return address;
            }).map((address) -> {
                c.setPhone(address.getPhone());
                return address;
            }).forEachOrdered((address) -> {
                c.setCityId(address.getCityId());
            });
            cityList.stream().filter((city) -> (c.getCityId() == city.getCityId())).map((city) -> {
                c.setCity(city.getCity());
                return city;
            }).forEachOrdered((city) -> {
                c.setCountryId(city.getCountryId());
            });
            countryList.stream().filter((country) -> (c.getCountryId() == country.getCountryId())).forEachOrdered((country) -> {
                c.setCountry(country.getCountry());
            });
        }
        this.listc = FXCollections.observableArrayList(allCust);
    }
    
   
    /*
     *  Open "Add Customer" window
     */
    @FXML
    void doAdd(ActionEvent event) throws IOException {
        // Close this window
        Stage stage = (Stage) add.getScene().getWindow();
        stage.close();
        
        // Open "Add Customer" window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AddCustomer.fxml"));
        Views.AddCustomerController controller = new Views.AddCustomerController(thisUser);
        loader.setController(controller);

        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }

     /*
     *  Create the TableView for the Customer files page
     */
    private void showCustTV(){
        getCustInfo();
        
        nameC.setCellValueFactory(new PropertyValueFactory("customerName"));
        phoneC.setCellValueFactory(new PropertyValueFactory("phone"));
        addC.setCellValueFactory(new PropertyValueFactory("address"));
        cityC.setCellValueFactory(new PropertyValueFactory("city"));
        countryC.setCellValueFactory(new PropertyValueFactory("country"));
        
        cusTV.setItems(listc);
        cusTV.refresh();
    }

    
    /*
     *  Delete the selected customer from the database/table
     */
    @FXML
    void doDelete(ActionEvent event) {
        try{
            // TODO Delete selected customer
            Customer cuselect = this.cusTV.getSelectionModel().getSelectedItem();
            String deleteq = "DELETE FROM U06ZEq.customer WHERE customerId=?";
            PreparedStatement delst = DBconn.getConn().prepareStatement(deleteq);
            delst.setInt(1, cuselect.getCustomerId());
            delst.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }        
        catch(Exception e){ // Customer is not selected before delete button is clicked
            Alert alertrec = new Alert(Alert.AlertType.ERROR);
            alertrec.setTitle("Select Customer");
            alertrec.setContentText("Must select a customer to delete.");
            alertrec.showAndWait();
        }
        
        // Refresh Customer TableView
        cusTV.getItems().clear();
        showCustTV();
    }

    

   
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        cusData = new ArrayList();
        getCustInfo();
        showCustTV();
    }    
    
}
