/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;

import java.time.LocalDate;
import java.time.LocalDateTime;
import Model.DBconn;
import Model.TimeMethods;
import Model.User;
import java.io.IOException;
import java.net.URL;
import java.sql.PreparedStatement;
import Model.Appointment;
import Model.Customer;
import java.sql.SQLException;
import java.sql.Timestamp;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;


public class ModifyAppointmentController implements Initializable {
    final private User thisUser;
    final private int appointmentId;
    private ArrayList<Customer> listc;
    private Appointment selectAppt;
    private Appointment modify;//new appointment
    ObservableList<String> typeOptions;
    private ArrayList<Appointment> currentAppt;
    
    
    @FXML private Button save;

    @FXML private Button cancel;
    
    @FXML private DatePicker startT;

    @FXML private DatePicker endT;

    @FXML private TextField title;

    @FXML private TextField description;

    @FXML private TextField contact;

    @FXML private TextField url;

    @FXML private TextField location;

    @FXML private ChoiceBox<String> custBox; 
    
    @FXML private Spinner<String> apstart;

    @FXML private Spinner<String> apend;  

    @FXML private Spinner<String> startspin;

    @FXML private Spinner<String> endspin;

    @FXML private ChoiceBox<String> type;
    
    
    
    public ModifyAppointmentController(User thisUser, int appointmentId){
        this.thisUser = thisUser;
        this.appointmentId = appointmentId;
        this.listc = new ArrayList();
        this.selectAppt = new Appointment();
        this.modify = new Appointment();
        this.typeOptions = FXCollections.observableArrayList("Coffee Meeting", "Brunch Meeting", "Onsite Conference", "Tele-Conference");
        this.currentAppt = new ArrayList();
    }
      
    
   
    private void modifyThisAppointment(){
         Timestamp timestamp = new Timestamp(System.currentTimeMillis());
        
        modify.setTitle(title.getText());
        modify.setDescription(description.getText());
        modify.setContact(contact.getText());
        modify.setUrl(url.getText());
        modify.setLocation(location.getText());
        modify.setCreateDate(timestamp);
        modify.setCreatedBy(thisUser.getUserName());
        modify.setLastUpdate(timestamp);
        modify.setLastUpdateBy(thisUser.getUserName());
        modify.setType(type.getValue());
        modify.setUserId(thisUser.getUserId());
        
        // Set Customer ID of selected customer
        for (int i = 0; i < listc.size(); i++){
            if (!listc.get(i).getCustomerName().equals(this.custBox.getValue())){
            } else {
                int custId = listc.get(i).getCustomerId();
                modify.setCustomerId(custId);
            }
        }
        
        // Get date "YYYY-MM-DD"
        LocalDate startDate = startT.getValue();
        LocalDate endDate = endT.getValue();
        
        // Get time
        String begin = this.startspin.getValue();
        String finish = this.endspin.getValue();
        String apbegin = this.apstart.getValue();
        String apfinish = this.apend.getValue();
        
        
        // Create a timestamp and set the Start and End values of Appointment
        Timestamp startStamp = TimeMethods.getTimestamp(startDate, begin, apbegin);   
        Timestamp endStamp = TimeMethods.getTimestamp(endDate, finish, apfinish);
        modify.setStart(startStamp);
        modify.setEnd(endStamp);
    }
    
    /*
     *  Check if the selected appointment time falls within business hours
     *  - return true if it falls within business hours
     *  - return false if it falls outside of business hours
     */
    private boolean companyScheduledHours(){
        // Get date "YYYY-MM-DD"
        LocalDate startDay = startT.getValue();
        LocalDate endDate = endT.getValue();
        
        // Get time
        String startHours = this.startspin.getValue();
        String endHours = this.endspin.getValue();
        String apstrt = this.apstart.getValue();
        String apover = this.apend.getValue();
        
        // Create a timestamp and set the Start and End values of Appointment
        Timestamp startTimestamp = TimeMethods.getTimestamp(startDay, startHours, apstrt);   
        Timestamp endTimestamp = TimeMethods.getTimestamp(endDate, endHours, apover);
        
        if (TimeMethods.hourToken(startTimestamp) < 7 || TimeMethods.hourToken(endTimestamp) > 18){
            return false;
        } else {
        }
        System.out.println("found business hours");
        return true;
    }
    
    /*
     *  Add the newly created appointment to the database
     */
    private void updateModifiedAppointmentDB(){
        String iQ = "UPDATE U06ZEq.appointment SET customerId=?, title=?, description=?, location=?, contact=?, url=?, start=?, end=?, lastUpdate=?, lastUpdateBy=?, userId=?, type=? WHERE appointmentId=?";
        
        try{
            PreparedStatement mod = DBconn.getConn().prepareStatement(iQ);
            mod.setInt(1, modify.getCustomerId());
            mod.setString(2, modify.getTitle());
            mod.setString(3, modify.getDescription());
            mod.setString(4, modify.getLocation());
            mod.setString(5, modify.getContact());
            mod.setString(6, modify.getUrl());
            mod.setTimestamp(7, DBconn.convertToUTC(modify.getStart()));
            mod.setTimestamp(8, DBconn.convertToUTC(modify.getEnd()));
            mod.setTimestamp(9, modify.getLastUpdate());
            mod.setString(10, modify.getLastUpdateBy());
            mod.setInt(11, modify.getUserId());
            mod.setString(12, modify.getType());
            mod.setInt(13, appointmentId);
            mod.execute();
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
    }
    @FXML
    void doCancel(ActionEvent event) throws IOException {
        // Close this window
        Stage stage = (Stage) cancel.getScene().getWindow();
        stage.close();
        
        // Load Appointments Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AppointmentsCenter.fxml"));
        Views.AppointmentsCenterController controller = new Views.AppointmentsCenterController(thisUser);
        loader.setController(controller);
        
        Parent root = loader.load();
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    /*
     *  Returns an array with format 
     *    [H], [m], [am/pm]
     */
    private Integer[] formatTime(Timestamp timestamp){
        Integer[] time = new Integer[3];
        String[] tokens = timestamp.toString().split(" ");
        String[] tokens2 = tokens[1].split(":");
        int hour = Integer.parseInt(tokens2[0]);
        int min = Integer.parseInt(tokens2[1]);
        
        // special case 00:00 = 12:00 AM
        if (hour != 0)if (hour <= 0 || hour >= 12)if (hour != 12)if (hour <= 12){
            time[0] = 12;
            time[2] = 1;
        }
        // 1:00 AM - 11:00 AM
        else {
            hour = hour - 12;
            time[0] = hour;
            time[2] = 0; // 1=AM, 0 = PM
        }
        // 1:00 PM - 11:00 PM (13:00 - 23:00)
        else {
            time[0] = hour;
            time[2] = 0;
        }
        // Special case 12:00 PM
        else {
            time[0] = hour;
            time[2] = 1;
        }
        
        time[1] = min;
        
        return time;
    }
   
    private void defaultTime(){
        ObservableList<String> apOptions = FXCollections.observableArrayList("am", "pm");
        ObservableList<String> timeOptions = FXCollections.observableArrayList(
                "12:00", "1:00", "2:00", "3:00", "4:00", "5:00", "6:00", "7:00", "8:00", "9:00", "10:00", "11:00");

        SpinnerValueFactory<String> begin = new SpinnerValueFactory.ListSpinnerValueFactory<>(timeOptions);
        SpinnerValueFactory<String> finish = new SpinnerValueFactory.ListSpinnerValueFactory<>(timeOptions);
        SpinnerValueFactory<String> apbegin = new SpinnerValueFactory.ListSpinnerValueFactory<>(apOptions);
        SpinnerValueFactory<String> apfinish = new SpinnerValueFactory.ListSpinnerValueFactory<>(apOptions);
      
        // Start Default Values
        Integer[] defaultDisplay = formatTime(this.selectAppt.getStart()); // Returns [H], [m], [am/pm]
        LocalDateTime display = this.selectAppt.getStart().toLocalDateTime();
        
        if (defaultDisplay[2] != 1){
            if (defaultDisplay[1]!=0){
                begin.setValue(defaultDisplay[0] + ":" + defaultDisplay[1]);
                apbegin.setValue("pm");
            }
            else{
                begin.setValue(defaultDisplay[0] + ":00");
                apbegin.setValue("pm");
            }
        }
        else{ // am
            if (defaultDisplay[1]!=0){
                finish.setValue(defaultDisplay[0] + ":" + defaultDisplay[1]);
                apbegin.setValue("am");
            }
            else{
                begin.setValue(defaultDisplay[0] + ":00");
                apbegin.setValue("am");
            }
        }
       
        // End Default Values
        Integer[] endDisplayDefault = formatTime(this.selectAppt.getEnd()); // Returns [H], [m], [am/pm]
        LocalDateTime endDate = this.selectAppt.getEnd().toLocalDateTime();
        if (endDisplayDefault[2] != 1){ // pm
            if (endDisplayDefault[1] != 0){
                finish.setValue(endDisplayDefault[0] + ":" + endDisplayDefault[1]);
                apfinish.setValue("pm");
            }
            else{
                finish.setValue(endDisplayDefault[0] + ":00");
                apfinish.setValue("pm");
            }
        }
        else{ // am
            if (endDisplayDefault[1] != 0){
                finish.setValue(endDisplayDefault[0] + ":" + endDisplayDefault[1]);
                apfinish.setValue("am");
            }
            else{
                finish.setValue(endDisplayDefault[0] + ":00");
                apfinish.setValue("am");
            }
        }
        
        this.startspin.setValueFactory(begin);
        this.endspin.setValueFactory(finish);
        this.apstart.setValueFactory(apbegin);
        this.apend.setValueFactory(apfinish);
        this.startT.setValue(this.selectAppt.getStart().toLocalDateTime().toLocalDate());
        this.endT.setValue(this.selectAppt.getEnd().toLocalDateTime().toLocalDate());
    }
    
    
    @FXML
    void doSave(ActionEvent event) throws IOException {
        if (!doAppointmentsOverLap() && companyScheduledHours()){
            modifyThisAppointment();
            updateModifiedAppointmentDB();

            // Close
            Stage stage = (Stage) cancel.getScene().getWindow();
            stage.close();
            
            // Load 
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AppointmentsCenter.fxml"));
            Views.AppointmentsCenterController controller = new Views.AppointmentsCenterController(thisUser);
            loader.setController(controller);

            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage primaryStage = new Stage();
            primaryStage.setScene(scene);
            primaryStage.show();
        }
        else{
            Alert alert = new Alert(Alert.AlertType.WARNING);
            alert.setTitle("Appointment");
            alert.setContentText("Invalid. Please change appointment time.");
            alert.showAndWait();
        }
    }
    
    
    /*
     *  Check if new appointment overlaps with any existing appointments
     */
    private boolean doAppointmentsOverLap(){
        // selections of the user
        Timestamp selectedTime = TimeMethods.getTimestamp(this.startT.getValue(), this.startspin.getValue(), this.apstart.getValue());
        Timestamp endselect = TimeMethods.getTimestamp(this.endT.getValue(), this.endspin.getValue(), this.apend.getValue());
        
        // Compare user's selections to existing appointments
        for (int i = 0; i < this.currentAppt.size(); i++){
            // After start time AND before end time
            if (this.appointmentId == this.currentAppt.get(i).getAppointmentId())
                continue;
            if ((selectedTime.after(this.currentAppt.get(i).getStart()) && (selectedTime.before(this.currentAppt.get(i).getEnd()))))
                return true;
            if ((selectedTime.equals(this.currentAppt.get(i).getStart()) && (endselect.after(this.currentAppt.get(i).getEnd()))))
                return true;
            if ((selectedTime.equals(this.currentAppt.get(i).getStart()) && (endselect.equals(this.currentAppt.get(i).getEnd()))))
                return true;
            if (endselect.after(this.currentAppt.get(i).getStart()) && (endselect.before(this.currentAppt.get(i).getEnd())))
                return true;
            if (endselect.after(this.currentAppt.get(i).getStart()) && (endselect.equals(this.currentAppt.get(i).getEnd()))){
                System.out.println("found overlap");
                return true;
            } else {
            }
        }
        return false;
    }
 /*
     *  Display the selected appointment's data in the fields
     */
    void setModifiedApptFields(){
        title.setText(selectAppt.getTitle());
        description.setText(selectAppt.getDescription());
        location.setText(selectAppt.getLocation());
        contact.setText(selectAppt.getContact());
        url.setText(selectAppt.getUrl());
        
        // Set default customer in Choice Box
        for (int i = 0; i < listc.size(); i++){
            if (listc.get(i).getCustomerId() != selectAppt.getCustomerId()){
            } else {
                custBox.getSelectionModel().select(i);
            }
        }
        
        // Set default Type in Choice Box
        for (int i = 0; i < typeOptions.size(); i++){
            if (!selectAppt.getType().equals(typeOptions.get(i))){
            } else {
                this.type.setValue(this.typeOptions.get(i));
            }
        }
    }

    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.listc = DBconn.getCustomers("SELECT * FROM U06ZEq.customer");
        this.selectAppt = DBconn.getSelectedAppt("SELECT * FROM U06ZEq.appointment WHERE appointmentId=?", appointmentId);
        this.currentAppt = DBconn.getAppointments("SELECT * FROM U06ZEq.appointment");

        ObservableList<String> customerChoices = FXCollections.observableArrayList();
        for (int i = 0; i < listc.size(); i++){
            customerChoices.add(listc.get(i).getCustomerName());
        }
        this.custBox.setItems(customerChoices);
        setModifiedApptFields();
        defaultTime();
        this.type.setItems(typeOptions);
    }    
    
}
