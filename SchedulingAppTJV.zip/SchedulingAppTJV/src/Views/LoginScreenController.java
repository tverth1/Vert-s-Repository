/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;



import Model.User; 
import java.io.IOException;
import java.sql.Timestamp;
import java.sql.PreparedStatement;
import java.io.FileWriter;
import java.sql.SQLException;
import java.io.BufferedWriter;
import Model.DBconn;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import java.sql.ResultSet;
import java.net.URL;
import java.io.File;
import javafx.scene.control.TextField;
import javafx.scene.control.PasswordField;
import java.util.Locale;
import javafx.scene.control.Label;
import javafx.scene.Scene;
import javafx.scene.Parent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import java.util.ResourceBundle;
import java.util.PropertyResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.stage.Stage;

/**
 * LoginScreen controller
 *
 * @author TJV
 */
public class LoginScreenController implements Initializable {
    
    
    private User thisUser;
    private Locale loc;
    private Timestamp loginTime;
    private ResourceBundle bundle;
    
    @FXML  private Label usernameLabel;

    @FXML  private Label usernamePassword;

    @FXML  private Label title;
    @FXML  private TextField usernameTextField;

    @FXML  private PasswordField passwordTextField;

    @FXML  private Button submit;

    @FXML  private Button cancel;
    
    //will log all users logging into application.
    
        private void logTracker(){
        String uName = thisUser.getUserName();//username
        String fName = thisUser.getUserName() + ".txt"; //filename
        String dir = System.getProperty("user.dir");
        String absoluteFilePath = dir + File.separator + fName;
        
        try{
            // Create File
            File log = new File(absoluteFilePath);

            // Check if file exists
            if (!log.exists()){ // Otherwise, write into the new file
                log.createNewFile();
                try (FileWriter fw = new FileWriter(log,true); 
                        BufferedWriter fo = new BufferedWriter(fw)) {
                    fo.write(uName + "\t" + this.loginTime);
                    fo.newLine();
                }
            }
            else{ try ( // If it exists, add onto file
                    FileWriter fw = new FileWriter(log,true);
                    BufferedWriter fo = new BufferedWriter(fw)) {
                fo.write(uName + "\t" + this.loginTime);
                fo.newLine();
            }
            }
        }
        catch(IOException ie){
            ie.printStackTrace();
        }
    }
    
    

    @FXML //saves a log file by user
    void doSubmit(ActionEvent event) throws IOException, SQLException {
        // Save user's login time
        loginTime = new Timestamp(System.currentTimeMillis());
        
        //If user's credentials are VALID, set currentUser and open Main Screen
        PreparedStatement enter = DBconn.getConn().prepareStatement("SELECT * FROM U06ZEq.user WHERE userName=? AND password=?");
        enter.setString(1, this.usernameTextField.getText());
        enter.setString(2, this.passwordTextField.getText());
        ResultSet rs = enter.executeQuery();
        
        if (!rs.next()){
            Alert subalert = new Alert(Alert.AlertType.ERROR);
            subalert.setTitle(bundle.getString("errtitle"));
            subalert.setContentText(bundle.getString("error"));
            subalert.showAndWait();
        }
        // If user's credentials are NOT VALID, display error message
        else{
            thisUser = thisUser.pullUser(rs);
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/AppointmentsCenter.fxml"));
            Views.AppointmentsCenterController controller = new Views.AppointmentsCenterController(thisUser, loginTime, true);
            loader.setController(controller);
            logTracker();
            
            // Close this window
            Stage stage = (Stage) submit.getScene().getWindow();
            stage.close();

            // Open Main Window
            Parent root = loader.load();
            Scene scene = new Scene(root);
            Stage primaryStage = new Stage();
            primaryStage.setScene(scene);
            primaryStage.show();
        }
    }
    @FXML
    void doCancel(ActionEvent event) {
        // Close window. End program.
        Platform.exit();
    }
    
    /**
     * Initializes the controller class and initializes database connection
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        DBconn.init();
        thisUser = new User();
        
        loc = Locale.getDefault();
        rb = ResourceBundle.getBundle("Login", loc);
        bundle = rb;
        
        submit.setText(rb.getString("submit"));
        cancel.setText(rb.getString("cancel"));
        usernamePassword.setText(rb.getString("password"));
        usernameLabel.setText(rb.getString("username"));
        title.setText(rb.getString("title"));
        
    }    
  }  
