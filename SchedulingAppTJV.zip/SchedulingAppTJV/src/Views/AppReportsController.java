/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Views;


import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.io.IOException;
import Model.DBconn;
import Model.User;
import Model.Customer;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import java.net.URL;
import Model.Appointment;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;



public class AppReportsController implements Initializable {
    private ObservableList<User> consultantObsList;
    private ObservableList<Customer> customerObsList;
    private ObservableList<Appointment> apptObsList;
    
    @FXML private Button appointment;

    @FXML private Button consultant;

    @FXML private Button customer;

    @FXML private Button backBtn;
    
    private ObservableList<String> months;
    private  ArrayList<User> consultantArray;
    private  ArrayList<Customer> listc;
    private  ArrayList<Appointment> currentAppt;
    private  User thisUser;

   @FXML private ChoiceBox<String> pickmonth; 

    @FXML private TableColumn<Appointment, String> titleC;

    @FXML private TableColumn<Appointment, String> typeC;

    @FXML private TableColumn<Appointment, String> descriptionC;

    @FXML private TableColumn<Appointment, String> locationC;

    @FXML private TableColumn<Appointment, String> contactC;

    @FXML private TableColumn<Appointment, Timestamp> startC;

    @FXML private TableColumn<Appointment, Timestamp> endC;

    @FXML private TableColumn<Appointment, String> urlC;
    
    @FXML private ChoiceBox<User> pickconsultant;

    @FXML private ChoiceBox<Customer> pickcustomer;

    @FXML private TableView<Appointment> reportTbl;
    
    public AppReportsController(User thisUser){
        this.thisUser = thisUser;
        this.consultantArray = new ArrayList();
        this.listc = new ArrayList();
        this.currentAppt = new ArrayList();
    }
    
     
    private void showOptions(){
        // Set Month Chooser items
        months = FXCollections.observableArrayList(
                "January", "February","March", "April",
                "May", "June", "July", "August", "September",
                "October", "November", "December");
        this.pickmonth.setItems(months);
        this.pickmonth.getSelectionModel().selectFirst();
        
        // Set Consultant Chooser items
        this.pickconsultant.setItems(consultantObsList);
        this.pickconsultant.getSelectionModel().selectFirst();
        
        // Set Customer Chooser items
        this.pickcustomer.setItems(customerObsList);
        this.pickcustomer.getSelectionModel().selectFirst();
    }
 
   

    private void pullUserDB(){
        try{
            // Pull from User Database
            String user = "SELECT * FROM U06ZEq.user";
            PreparedStatement userStmt = DBconn.getConn().prepareStatement(user);
            ResultSet userRslt = userStmt.executeQuery();
            
            while (userRslt.next()){ // populate consultantList
                User tempUser = new User();
                tempUser.setUserId(userRslt.getInt("userId"));
                tempUser.setUserName(userRslt.getString("userName"));
                this.consultantArray.add(tempUser);                
            }
            
            // Pull from Customer Database
            String cust = "SELECT * FROM U06ZEq.customer";
            PreparedStatement customerStmt = DBconn.getConn().prepareStatement(cust);
            ResultSet customerRslt = customerStmt.executeQuery();
            
            while (customerRslt.next()){ // populate customerList
                Customer tempCustomer = new Customer();
                tempCustomer.setCustomerId(customerRslt.getInt("customerId"));
                tempCustomer.setCustomerName(customerRslt.getString("customerName"));
                this.listc.add(tempCustomer);
            }
            
            // Pull from Appointment Database
            String appt = "SELECT * FROM U06ZEq.appointment";
            PreparedStatement apptStmt = DBconn.getConn().prepareStatement(appt);
            ResultSet apptRslt = apptStmt.executeQuery();
            
            while (apptRslt.next()){ // populate apptList
                Appointment tempAppt = new Appointment();
                tempAppt.setTitle(apptRslt.getString("title"));
                tempAppt.setType(apptRslt.getString("type"));
                tempAppt.setDescription(apptRslt.getString("description"));
                tempAppt.setLocation(apptRslt.getString("location"));
                tempAppt.setContact(apptRslt.getString("contact"));
                tempAppt.setStart(DBconn.convertFromUTC(apptRslt.getTimestamp("start")));
                tempAppt.setEnd(DBconn.convertFromUTC(apptRslt.getTimestamp("end")));
                tempAppt.setCustomerId(apptRslt.getInt("customerId"));
                tempAppt.setUserId(apptRslt.getInt("userId"));
                tempAppt.setUrl(apptRslt.getString("url"));
                this.currentAppt.add(tempAppt);
            }
        }
        catch(SQLException sqle){
            sqle.printStackTrace();
        }
        
        // Convert ArrayLists to corresponding ObservableLists
        this.consultantObsList = FXCollections.observableArrayList(consultantArray);
        this.customerObsList = FXCollections.observableArrayList(listc);
        this.apptObsList = FXCollections.observableArrayList(currentAppt);
    }
    /*
     *  All appointments associated with selected customer
     */
    @FXML
    void doCustomer(ActionEvent event) {
        Customer selectedCustomer = this.pickcustomer.getSelectionModel().getSelectedItem();
        ArrayList<Appointment> assocAppts = this.getAppointments(selectedCustomer);
        this.showTV(assocAppts);
    }
    
    @FXML
    void doBack(ActionEvent event) throws IOException {
        // Close this window
        Stage stage = (Stage) backBtn.getScene().getWindow();
        stage.close();
    }
    /*
     *  All appointments associated with selected consultant
     */
    @FXML
    void doConsultant(ActionEvent event) {
        User selectedConsultant = this.pickconsultant.getSelectionModel().getSelectedItem();
        ArrayList<Appointment> assocAppts = this.getAppointments(selectedConsultant);
        this.showTV(assocAppts);
    }
 
 private void showTV(ArrayList<Appointment> assocAppts){
        // Associate all columns with corresponding appointment properties
        this.endC.setCellValueFactory(new PropertyValueFactory("end"));
        this.startC.setCellValueFactory(new PropertyValueFactory("start"));
        this.urlC.setCellValueFactory(new PropertyValueFactory("url"));
        this.contactC.setCellValueFactory(new PropertyValueFactory("contact"));
        this.locationC.setCellValueFactory(new PropertyValueFactory("location"));
        this.descriptionC.setCellValueFactory(new PropertyValueFactory("description"));
        this.typeC.setCellValueFactory(new PropertyValueFactory("type"));
        this.titleC.setCellValueFactory(new PropertyValueFactory("title"));
        
        // Convert to ObservableList
        ObservableList<Appointment> assocObsList = FXCollections.observableArrayList(assocAppts);
        
        // Display
        this.reportTbl.setItems(assocObsList);
        this.reportTbl.refresh();
    }

   
   
     /*
     *  Number of appointment types by month
     */
    @FXML
    void doApptReport(ActionEvent event) throws IOException {
        ArrayList<Integer> meetingrep = new ArrayList();
        int thisMonth = this.pickmonth.getSelectionModel().getSelectedIndex() + 1; // get selected month number
        int coffee = 0;
        int brunch = 0;
        int onsite = 0;
        int tele = 0;
        
        for (int i = 0; i < this.currentAppt.size(); i++){
            int m = this.getMonth(this.currentAppt.get(i).getStart());
            String meet = this.currentAppt.get(i).getType();
            if (m != thisMonth){
            } else {
                switch (meet) {
                    case "Coffee Meeting":
                        coffee++;
                        break;
                    case "Brunch Meeting":
                        brunch++;
                        break;
                    case "Onsite Conference":
                        onsite++;
                        break;
                    case "Tele-Conference":
                        tele++;
                        break;
                    default:
                        break;
                }
            }
        }
        
        meetingrep.add(tele); //0
        meetingrep.add(onsite);//1
        meetingrep.add(brunch);//2
        meetingrep.add(coffee);//3
        
        
        // Load Appointments Window
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/Views/TypeByMonth.fxml"));
        Views.TypeByMonthController controller = new Views.TypeByMonthController(this.pickmonth.getValue(), meetingrep);
        loader.setController(controller);
        
        Parent root = loader.load(); 
        Scene scene = new Scene(root);
        Stage primaryStage = new Stage();
        primaryStage.setScene(scene);
        primaryStage.show();
    }
   
    private ArrayList<Appointment> getAppointments(Customer cust){
        ArrayList<Appointment> assocAppts = new ArrayList();
        
        for (int i = 0; i < currentAppt.size(); i++){
            if (currentAppt.get(i).getCustomerId() != cust.getCustomerId()){
            } else {
                assocAppts.add(currentAppt.get(i));
            }
        }
        
        return assocAppts;
    }
    
    private ArrayList<Appointment> getAppointments(User consult){
        ArrayList<Appointment> assocAppts = new ArrayList();
        
        for (int i = 0; i < currentAppt.size(); i++){
            if (currentAppt.get(i).getUserId() != consult.getUserId()){
            } else {
                assocAppts.add(currentAppt.get(i));
            }
        }
        
        return assocAppts;
    }
    
     /*
     *  Extract the month part of the timestamp and return the int of that month
     */
    private int getMonth(Timestamp timestamp){
        
        // Break timestamp into tokens
        String[] tokens = timestamp.toString().split(" ");
        
        // tokens[0] is date stamp
        String date = tokens[0];
        
        // substring loc 5-7 is month
        String month = date.substring(5, 7);
        
        // parse substring to int
        int gottenMonth = Integer.parseInt(month);
        
        return gottenMonth;
    }
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        pullUserDB();
        showOptions();
    }    
    
}
