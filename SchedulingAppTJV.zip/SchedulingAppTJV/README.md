## Scheduling Machine

## Built With

* [Netbeans](https://netbeans.org/kb/index.html) - The IDE used to create application
* [MySQL Workbench](https://www.mysql.com/products/workbench/) - Used to design the database

## Timeline of Project

02/24/20- 3/20/20:
- Created functions
- GUI for smooth user experience
- Connected to Ucertity db & uploaded sample data

3/26/20:
- Final debugging of functions
- Inserted sample data in database to include more users

PENDING:
- Submission

## Written by:
Timothy John Verthein
## License
Created for WGU C195 CS course

