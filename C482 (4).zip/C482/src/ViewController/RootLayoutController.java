/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewController;

import C482.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.MenuItem;

public class RootLayoutController {
    private Main main;
    private boolean dummyDataLoaded;

    public RootLayoutController(Main main) {
        this.main = main;
    }

    @FXML public MenuItem fileCloseMenuItem;

    //Handle fileCloseMenuClick
    @FXML
    public void handleClose(ActionEvent event) {
        System.exit(0);
    }

    // about dialog
    @FXML public void handleAbout() {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("C482 Project");
        alert.setHeaderText("Software I");
        alert.setContentText("Author: Timothy Verthein");

        // Show alert
        alert.showAndWait();
    }

    /**
     * Menu option to load dummy data into inventory program.
     */
    @FXML public void loadDummyData() {
        if(!dummyDataLoaded){
            main.generateDummyData();
            dummyDataLoaded = true;
        } else {
            Alerts.warningAlert("Dummy data already loaded.");
        }
    }
}