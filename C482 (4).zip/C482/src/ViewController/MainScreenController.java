/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ViewController;

import C482.*;
import Model.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.stage.Modality;

public class MainScreenController implements Initializable {
    private Inventory inventory;
    private BorderPane rootLayout; 
    private ObservableList<Part> partList = FXCollections.observableArrayList();
    private ObservableList<Product> productList = FXCollections.observableArrayList();
    @FXML public TableView<Part> partTableView;
    @FXML public TableView<Product> productTableView;
    @FXML public TableColumn partIDColumn, partNameColumn, partInventoryLevelColumn, partPriceCostColumn;
    @FXML public TableColumn productIDColumn, productNameColumn, productInventoryLevelColumn, productPriceCostColumn;
    @FXML public Button partDeleteButton, productDeleteButton;
    @FXML public Button partModifyButton, productModifyButton;
    @FXML public Button exitButton;
    @FXML private TextField textFieldPartSearch, textFieldProductSearch;

    public MainScreenController(Inventory inventory, BorderPane rootLayout) {
       
        this.inventory = inventory;
        this.rootLayout = rootLayout;
    }

    /**
     * Shows the AddPart scene
     * @throws IOException If FXML fails to load
     */
    public void showAddPart() throws IOException {
        // Instantiate the controller and give it access to inventory.
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/ViewController/AddPart.fxml"));
        AddPartController controller = new AddPartController(inventory, rootLayout);
        loader.setController(controller);

        AnchorPane addPart = loader.load();
        rootLayout.setCenter(addPart);
    }

    /**
     * Shows the ModifyPart scene
     * @param partToModify The part selected to modify
     * @throws IOException If FXML fails to load
     */
    public void showModifyPart(Part partToModify) throws IOException {
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/ViewController/ModifyPart.fxml"));
        ModifyPartController controller = new ModifyPartController(partToModify,inventory, rootLayout);
        loader.setController(controller);

        AnchorPane modifyPart = loader.load();
        rootLayout.setCenter(modifyPart);
    }

    /**
     * Enable or disable buttons when table items are selected.
     */
    public void userClickedOnPartTable() {
        this.partDeleteButton.setDisable(false);
        this.partModifyButton.setDisable(false);
    }

    /**
     * Enable or disable buttons when table items are selected.
     */
    public void userClickedOnProductTable() {
        this.productDeleteButton.setDisable(false);
        this.productModifyButton.setDisable(false);
    }

    /**
     * Shows a confirmation dialog before deleting the selected part
     */
    public void deletePartButtonPressed() {
        ObservableList<Part> selectedRows = partTableView.getSelectionModel().getSelectedItems();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Remove Part?");
        alert.setHeaderText("Are you sure you want to delete said Part?");
        StringBuilder partsToDelete = new StringBuilder();
        // Iterates through matching parts to get names to confirm
        selectedRows.forEach((part) -> {
            partsToDelete.append(part.getName()).append("\n");
        });
        alert.setContentText("Remove Part:\n\n" + partsToDelete);
        Optional<ButtonType> optional = alert.showAndWait();
        if(optional.get() == ButtonType.OK) {
            inventory.removeParts(selectedRows);
            partTableView.getSelectionModel().clearSelection();
        }
    }

    /**
     * confirmation dialog before deleting product.
     */
    public void deleteProductButtonPressed() {
        boolean isDeletable = true;
        ObservableList<Product> selectedRows;

        // Gets selected rows
        selectedRows = productTableView.getSelectionModel().getSelectedItems();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setTitle("Remove Product?");
        alert.setHeaderText("Are you sure you want to delete said Product?");
        StringBuilder productsToDelete = new StringBuilder();
        // Iterates through matching parts to get names to confirm
        selectedRows.forEach((product) -> {
            productsToDelete.append(product.getName()).append("\n");
        });
        alert.setContentText("Remove Products:\n\n" + productsToDelete);
        Optional<ButtonType> optional = alert.showAndWait();
        if(optional.get() == ButtonType.OK) {
            for(Product product: selectedRows) {
                String validateDelete = Validation.validateDeleteProduct(product);
                if(!validateDelete.isEmpty()) {
                    Alerts.warningAlert(validateDelete);
                    isDeletable = false;
                }
            }
            if(isDeletable) {
                inventory.removeProducts(selectedRows);
                productTableView.getSelectionModel().clearSelection();
            }
        }
    }

    /**
     * Controls modify part button press. Validates only changed field.
     * @throws java.io.IOException
     */
    public void modifyPartButtonPressed() throws IOException{
        // Only allow single object selection
        ObservableList<Part> selectedRows = partTableView.getSelectionModel().getSelectedItems();
        if(selectedRows.size() > 1) {
            Alerts.warningAlert("You can only modify one item at a time.");
        } else {
            Part partToModify = partTableView.getSelectionModel().getSelectedItem();
            showModifyPart(partToModify);
        }
    }

    /**
     * Shows AddProduct screen.
     * @throws IOException If FXML fails to load.
     */
    public void showAddProduct() throws IOException {
        // Instantiate the controller and give it access to inventory
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/ViewController/AddProduct.fxml"));
        AddProductController controller = new AddProductController(inventory, rootLayout);
        loader.setController(controller);

        AnchorPane addProduct = loader.load();
        rootLayout.setCenter(addProduct);
    }

    /**
     * Shows modify product screen.
     * @param productToModify The product to modify.
     * @throws IOException If FXML fails to load.
     */
    public void showModifyProduct(Product productToModify) throws IOException {
        // Instantiate the controller and give it access to inventory
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(Main.class.getResource("/ViewController/ModifyProduct.fxml"));
        ModifyProductController controller = new ModifyProductController(inventory, rootLayout, productToModify);
        loader.setController(controller);

        AnchorPane modifyProduct = loader.load();
        rootLayout.setCenter(modifyProduct);
    }

    /**
     * Handles modify button pressed.
     * @throws IOException If FXML fails to load
     */
    public void modifyProductButtonPressed() throws IOException{
        // Only allow single object selection
        ObservableList<Product> selectedRows = productTableView.getSelectionModel().getSelectedItems();
        if(selectedRows.size() > 1) {
            Alerts.warningAlert("Modify only one item at a time.");
        } else {
            Product productToModify = productTableView.getSelectionModel().getSelectedItem();
            showModifyProduct(productToModify);
        }
    }

    /**
     * Shows the parts in the inventory in the table view.
     */
    private void showPartTableData() {
        // Only add items if the inventory is not empty.
        // Add all parts to filtered list
        FilteredList<Part> filteredParts = new FilteredList<>(inventory.getParts(), p -> true);
        textFieldPartSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredParts.setPredicate(part -> {
                if(newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Build filters
                String lowerCaseFilter = newValue.toLowerCase();

                if(part.getName().toLowerCase().contains(lowerCaseFilter)) {
                    return true; // Matches part name
                } else if(String.valueOf(part.getPartID()).contains(lowerCaseFilter)) {
                    return true; // ID Matches
                }
                return false; // No matches
            });
        });

        // Wrap filtered list in sorted list
        SortedList<Part> sortedParts = new SortedList<>(filteredParts);

        // Bind Sorted List to TableView
        sortedParts.comparatorProperty().bind(partTableView.comparatorProperty());

        partIDColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("partID"));
        partNameColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("name"));
        partInventoryLevelColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("inStock"));
        partPriceCostColumn.setCellValueFactory(new PropertyValueFactory<Part, String>("price"));
        partTableView.setItems(sortedParts);
        partTableView.refresh();
    }

    /**
     * Shows the products in the inventory in the table view.
     */
    public void showProductTableData() {
        // Add all products to filtered list
        FilteredList<Product> filteredProducts = new FilteredList<>(inventory.getProducts(), p -> true);
        textFieldProductSearch.textProperty().addListener((observable, oldValue, newValue) -> {
            filteredProducts.setPredicate(product -> {
                if(newValue == null || newValue.isEmpty()) {
                    return true;
                }

                // Build filters for search
                String lowerCaseFilter = newValue.toLowerCase();

                if(product.getName().toLowerCase().contains(lowerCaseFilter)) { // Matches 
                    return true;
                } else if(String.valueOf(product.getProductID()).contains(lowerCaseFilter)) { // matches 
                    return true;
                }
                return false;
            });
        });

        // Wrap filtered list in sorted list
        SortedList<Product> sortedProducts = new SortedList<>(filteredProducts);

        // Bind sorted list to table view
        sortedProducts.comparatorProperty().bind(productTableView.comparatorProperty());

        productIDColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("productID"));
        productNameColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("name"));
        productInventoryLevelColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("inStock"));
        productPriceCostColumn.setCellValueFactory(new PropertyValueFactory<Product, String>("price"));
        productTableView.setItems(sortedProducts);
        productTableView.refresh();
    }

    /**
     * Clears the search text box
     */
    public void clearTextFieldPartSearch() {
        textFieldPartSearch.clear();
    }

    /**
     * Clears the search text box
     */
    public void clearTextFieldProductSearch() {
        textFieldProductSearch.clear();
    }

    /**
     * Sets the column width to fit the entire space
     */
    public void setPartTableColumnWidth() {
        partIDColumn.prefWidthProperty().bind(partTableView.widthProperty().divide(4));
        partNameColumn.prefWidthProperty().bind(partTableView.widthProperty().divide(4));
        partInventoryLevelColumn.prefWidthProperty().bind(partTableView.widthProperty().divide(4));
        partPriceCostColumn.prefWidthProperty().bind(partTableView.widthProperty().divide(4));
    }

    /**
     * Allows the interface to choose which tab to return to after changing scenes.
     * @param url
     * @param event
     */  
   
    @FXML
    private void exitButton(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Exit Confirmation");
        alert.setHeaderText("Exit Confirmation");
        alert.setContentText("Are you sure you want to exit?");
        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == ButtonType.OK) {
            System.exit(0);
        }
        else {
            System.out.println("Canceled.");
        }
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // Allows editing for table and selecting multiple rows
        partTableView.setEditable(true);
        partTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        partTableView.setPlaceholder(new Label("No parts found."));
        productTableView.setEditable(true);
        productTableView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        productTableView.setPlaceholder(new Label("No products found."));
        setPartTableColumnWidth();
        showPartTableData();
        showProductTableData();
    }
}