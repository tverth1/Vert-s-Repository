/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

public class InHouse extends Part{
    private final IntegerProperty machineID;

    /**
     * Constructor
     */
    public InHouse() {
        super();
        this.machineID = new SimpleIntegerProperty();
    }

    /**
     * Setter
     * @param machineID Integer ID.  Should be unique
     */
    public void setMachineID(int machineID) {
        this.machineID.set(machineID);
    }

    /**
     * Getter
     * @return returns machine ID
     */
    public int getMachineID() {
        return this.machineID.getValue();
    }
}
