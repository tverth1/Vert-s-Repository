/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author User
 */
import javafx.beans.property.*;

public abstract class Part {
    private final IntegerProperty id;
    private final StringProperty name;
    private final DoubleProperty price;
    private final IntegerProperty stock;
    private final IntegerProperty min;
    private final IntegerProperty max;

    public Part() {
        this.id = new SimpleIntegerProperty();
        this.name = new SimpleStringProperty();
        this.price = new SimpleDoubleProperty();
        this.stock = new SimpleIntegerProperty();
        this.min = new SimpleIntegerProperty();
        this.max = new SimpleIntegerProperty();
    }

    // Getters and setters
    public void setName(String name) {
        this.name.set(name);
    }

    public void setPartID(int id) {
        this.id.set(id);
    }

    public void setPrice(double price) {
        this.price.set(price);
    }

    public void setStock(int stock) {
        this.stock.set(stock);
    }

    public void setMin(int min) {
        this.min.set(min);
    }

    public void setMax(int max) {
        this.max.set(max);
    }

    public int getPartID() {
        return id.getValue();
    }

    public String getName() {
        return name.getValue();
    }

    public double getPrice() {
        return price.getValue();
    }

    public int getStock() {
        return stock.getValue();
    }

    public int getMin() {
        return min.getValue();
    }

    public int getMax() {
        return max.getValue();
    }
}
